import { useState, useEffect } from "react";
import { Landmark, Mail, Phone, MapPin, Facebook, Twitter, Instagram, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { collection, getDocs, limit, query } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { motion } from "motion/react";

export default function Footer() {
  const [settings, setSettings] = useState<any>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const q = query(collection(db, "siteSettings"), limit(1));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          setSettings(snapshot.docs[0].data());
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, "siteSettings");
      }
    };
    fetchSettings();
  }, []);

  const siteName = settings?.siteName || "Shashemene City";
  const siteDescription = settings?.siteDescription || "The vibrant commercial hub and cultural melting pot of the Oromia Region, Ethiopia. Committed to sustainable growth and community excellence.";
  const contactEmail = settings?.contactEmail || "info@shashemene.gov.et";
  const contactPhone = settings?.contactPhone || "+251 46 123 4567";
  const address = settings?.address || "City Hall, Main Road, Shashemene";

  return (
    <footer className="bg-white text-stone-600 pt-32 pb-12 border-t border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-16 mb-24">
          <div className="md:col-span-5 space-y-10">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-12 h-12 bg-accent rounded-2xl flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                <Landmark className="w-7 h-7 text-white" />
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight text-text-dark">
                Shashemene <span className="text-accent italic">City</span>
              </span>
            </Link>
            <p className="text-lg leading-relaxed font-light max-w-md">
              {siteDescription}
            </p>
            <div className="flex gap-4">
              {[
                { icon: Facebook, href: settings?.facebook || "#" },
                { icon: Twitter, href: settings?.twitter || "#" },
                { icon: Instagram, href: settings?.instagram || "#" },
              ].map((social, idx) => (
                <a 
                  key={idx}
                  href={social.href} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-12 h-12 rounded-full border border-stone-200 flex items-center justify-center hover:bg-accent-hover hover:border-accent-hover hover:text-white transition-all duration-300"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div className="md:col-span-2">
            <h3 className="text-text-dark font-display font-bold tracking-widest uppercase text-xs mb-10">Quick Links</h3>
            <ul className="space-y-6">
              {[
                { name: "About the City", path: "/about" },
                { name: "Public Services", path: "/services" },
                { name: "City Gallery", path: "/gallery" },
                { name: "Latest News", path: "/news" },
                { name: "Contact Us", path: "/contact" },
              ].map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="hover:text-accent transition-colors flex items-center gap-2 group">
                    <span className="w-0 group-hover:w-4 h-[1px] bg-accent transition-all"></span>
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-5">
            <h3 className="text-text-dark font-display font-bold tracking-widest uppercase text-xs mb-10">Get in Touch</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-text-dark font-bold text-sm mb-1">Visit Us</p>
                    <p className="text-sm leading-relaxed">{address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-text-dark font-bold text-sm mb-1">Call Us</p>
                    <p className="text-sm">{contactPhone}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-text-dark font-bold text-sm mb-1">Email Us</p>
                    <p className="text-sm">{contactEmail}</p>
                  </div>
                </div>
                <Link 
                  to="/admin" 
                  className="inline-flex items-center gap-2 px-6 py-3 bg-secondary border border-stone-200 rounded-xl text-text-dark text-sm font-bold hover:bg-stone-100 transition-all"
                >
                  Admin Portal
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-12 border-t border-stone-100 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] uppercase tracking-[0.2em] font-bold">
          <p>© {new Date().getFullYear()} {siteName} Administration. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-accent transition-colors">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
