import { Link, useLocation } from "react-router-dom";
import { Menu, X, Landmark, Phone, Mail, Facebook, Twitter, Instagram, Sun, Moon } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export default function Navbar({ darkMode, setDarkMode }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "News", path: "/news" },
    { name: "Gallery", path: "/gallery" },
    { name: "Explore", path: "/explore" },
    { name: "Services", path: "/services" },
    { name: "Contact", path: "/contact" },
    { name: "Admin", path: "/admin" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-500">
      {/* Top Bar */}
      <div className={`bg-secondary text-text-dark py-2 px-4 sm:px-6 lg:px-8 transition-all duration-500 border-b border-stone-100 ${scrolled ? "h-0 opacity-0 overflow-hidden" : "h-auto opacity-100"}`}>
        <div className="max-w-7xl mx-auto flex justify-between items-center text-[10px] sm:text-xs font-medium tracking-wider uppercase">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-accent" />
              <span>+251 46 123 4567</span>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <Mail className="w-3 h-3 text-accent" />
              <span>info@shashemene.gov.et</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Facebook className="w-3 h-3 hover:text-accent cursor-pointer transition-colors" />
            <Twitter className="w-3 h-3 hover:text-accent cursor-pointer transition-colors" />
            <Instagram className="w-3 h-3 hover:text-accent cursor-pointer transition-colors" />
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <nav className={`transition-all duration-500 ${scrolled ? "bg-white/95 dark:bg-primary/95 shadow-lg py-3" : "bg-white/90 dark:bg-primary/90 py-5"} backdrop-blur-md border-b border-stone-100 dark:border-white/5`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                <Landmark className="w-6 h-6 text-accent" />
              </div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-text-dark dark:text-white">
                Shashemene <span className="text-accent italic">City</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-4 py-2 rounded-full text-sm font-bold transition-all relative group ${
                    location.pathname === link.path ? "text-accent dark:text-accent" : "text-stone-600 dark:text-stone-400 hover:text-accent dark:hover:text-accent"
                  }`}
                >
                  {link.name}
                  {location.pathname === link.path && (
                    <motion.div 
                      layoutId="nav-active"
                      className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-accent rounded-full"
                    />
                  )}
                </Link>
              ))}
              
              {/* Theme Toggle */}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="ml-4 p-2 text-stone-600 dark:text-stone-400 hover:text-accent dark:hover:text-accent transition-colors rounded-full hover:bg-secondary dark:hover:bg-stone-800"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <Link
                to="/explore"
                className="ml-4 px-6 py-2.5 bg-accent text-white rounded-full text-sm font-bold hover:bg-accent-hover transition-all shadow-md shadow-primary/10"
              >
                Visit Now
              </Link>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="flex items-center gap-2 md:hidden">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 text-stone-600 dark:text-stone-400 hover:text-accent transition-colors"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button
                className="p-2 text-stone-600 dark:text-stone-400 hover:text-accent transition-colors"
                onClick={() => setIsOpen(!isOpen)}
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white dark:bg-stone-900 border-t border-stone-100 dark:border-white/5 overflow-hidden"
            >
              <div className="px-4 py-8 space-y-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className={`block px-6 py-4 rounded-2xl text-lg font-bold transition-all ${
                      location.pathname === link.path
                        ? "bg-secondary dark:bg-primary/20 text-accent dark:text-accent"
                        : "text-stone-600 dark:text-stone-400 hover:bg-white dark:hover:bg-stone-800"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <div className="pt-6 px-6">
                  <Link
                    to="/explore"
                    onClick={() => setIsOpen(false)}
                    className="block w-full py-4 bg-accent text-white text-center rounded-2xl font-bold shadow-lg"
                  >
                    Explore Shashemene
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}
