import { useState, useEffect } from "react";
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { motion } from "motion/react";
import { Loader2, ArrowRight, Calendar } from "lucide-react";
import { Link } from "react-router-dom";

interface NewsItem {
  id: string;
  title: string;
  content: string;
  date: string;
  image: string;
  category: string;
}

const PAGE_SIZE = 3;

export default function NewsSection() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNews = async () => {
    setLoading(true);
    try {
      const newsQuery = query(
        collection(db, "news"),
        orderBy("date", "desc"),
        limit(PAGE_SIZE)
      );

      const snapshot = await getDocs(newsQuery);
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as NewsItem));
      setNews(items);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "news");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl"
        >
          <span className="text-orange-600 font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Latest Updates</span>
          <h2 className="text-5xl md:text-7xl font-display font-bold text-stone-900 dark:text-white leading-[1.1]">
            City News & <span className="text-orange-600 italic font-serif">Announcements</span>
          </h2>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <Link 
            to="/news" 
            className="flex items-center gap-3 text-stone-900 dark:text-white font-bold group"
          >
            View All News
            <div className="w-12 h-12 rounded-full border border-stone-200 dark:border-white/10 flex items-center justify-center group-hover:bg-orange-600 group-hover:border-orange-600 group-hover:text-white transition-all">
              <ArrowRight className="w-5 h-5" />
            </div>
          </Link>
        </motion.div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="w-10 h-10 text-orange-600 animate-spin" />
        </div>
      ) : news.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {news.map((item, idx) => (
            <motion.article
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group"
            >
              <div className="aspect-[16/10] rounded-[3rem] overflow-hidden relative mb-10">
                <img
                  src={item.image || `https://picsum.photos/seed/${item.id}/800/600`}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-8 left-8">
                  <span className="px-6 py-2 bg-white/90 dark:bg-stone-900/90 backdrop-blur-md text-orange-700 dark:text-orange-400 text-[10px] font-bold uppercase tracking-widest rounded-full shadow-sm">
                    {item.category}
                  </span>
                </div>
              </div>
              <div className="px-4">
                <div className="flex items-center gap-3 text-stone-400 text-xs font-bold uppercase tracking-widest mb-6">
                  <Calendar className="w-4 h-4 text-orange-600" />
                  {new Date(item.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </div>
                <h3 className="text-2xl font-bold text-stone-900 dark:text-white mb-6 group-hover:text-orange-600 transition-colors line-clamp-2 leading-tight">
                  {item.title}
                </h3>
                <p className="text-stone-500 dark:text-stone-400 leading-relaxed mb-10 line-clamp-2 font-light">
                  {item.content}
                </p>
                <Link to="/news" className="inline-flex items-center gap-2 text-orange-600 font-bold group/btn">
                  Read Full Story
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      ) : (
        <div className="text-center py-32 bg-white dark:bg-stone-900/30 rounded-[3rem] border border-stone-100 dark:border-white/5">
          <p className="text-stone-500">No news articles found at the moment.</p>
        </div>
      )}
    </div>
  );
}
