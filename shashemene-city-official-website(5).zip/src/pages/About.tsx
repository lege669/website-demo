import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { History, Globe, Map, Award, ArrowRight, Zap, Target, Users } from "lucide-react";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";

export default function About() {
  const [aboutPhotos, setAboutPhotos] = useState<any[]>([]);
  const { scrollYProgress } = useScroll();
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -200]);

  useEffect(() => {
    const q = query(
      collection(db, "photos"),
      where("section", "==", "About"),
      orderBy("order", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const photos = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setAboutPhotos(photos);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/About");
    });

    return () => unsubscribe();
  }, []);

  const historyPhotoUrl = aboutPhotos[0]?.url || "https://images.unsplash.com/photo-1523050853023-8c2d2909f4f3?auto=format&fit=crop&q=80&w=1000";
  const culturePhotoUrl = aboutPhotos[1]?.url || "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&q=80&w=1000";

  return (
    <div className="">
      {/* Hero Section */}
      <section className="relative h-[70vh] flex items-center overflow-hidden bg-white">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1444723121867-7a241cacace9?auto=format&fit=crop&q=80&w=1920"
            className="w-full h-full object-cover opacity-20"
            alt="About Hero"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-text-dark w-full">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <span className="text-accent font-display font-bold tracking-[0.3em] uppercase text-xs mb-8 block">Our Story</span>
            <h1 className="text-7xl md:text-9xl font-display font-bold leading-[0.9] mb-12 tracking-tighter">
              BEYOND the<br />
              <span className="text-accent italic font-serif">HORIZON</span>
            </h1>
            <p className="text-xl text-stone-600 leading-relaxed max-w-2xl font-light">
              Shashemene stands as a vibrant intersection of global heritage and modern commerce. We are committed to building a city that honors its past while embracing a sustainable future.
            </p>
          </motion.div>
        </div>
      </section>

      {/* History Section */}
      <section className="section-padding relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Our Legacy</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white mb-10 leading-[1.1]">
                A Legacy of <span className="text-accent italic font-serif">Unity</span> and Welcome
              </h2>
              <div className="space-y-6 text-xl text-text-dark/70 dark:text-stone-400 leading-relaxed font-light">
                <p>
                  Shashemene's modern history is uniquely tied to the land grant by Emperor Haile Selassie I in 1948 to the people of African descent who supported Ethiopia during the Italian invasion.
                </p>
                <p>
                  This historic gesture led to the establishment of a vibrant international community, making Shashemene a global symbol of repatriation and pan-Africanism.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="relative"
            >
              <div className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl">
                <img
                  src={historyPhotoUrl}
                  alt="Historical Shashemene"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <motion.div 
                style={{ y: y1 }}
                className="absolute -bottom-12 -right-12 w-64 h-64 bg-accent rounded-[2rem] p-10 text-white shadow-2xl hidden md:block"
              >
                <div className="text-5xl font-display font-bold mb-4">1948</div>
                <p className="text-sm font-medium opacity-80 leading-relaxed">The year Shashemene became a global symbol of unity.</p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding bg-white dark:bg-primary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { title: "Our Mission", icon: Target, desc: "To provide world-class urban infrastructure and services that empower our diverse community and foster economic growth." },
              { title: "Our Vision", icon: Zap, desc: "To become the leading smart city in Ethiopia, recognized for its cultural richness and sustainable innovation." },
              { title: "Our Values", icon: Users, desc: "Inclusivity, transparency, and excellence in everything we do for the citizens of Shashemene." },
            ].map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-12 bg-white dark:bg-primary rounded-[3rem] border border-secondary dark:border-white/5"
              >
                <div className="w-16 h-16 bg-accent/10 dark:bg-accent/20 rounded-2xl flex items-center justify-center mb-10">
                  <item.icon className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold text-text-dark dark:text-white mb-6">{item.title}</h3>
                <p className="text-text-dark/60 dark:text-stone-400 leading-relaxed font-light">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Culture Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="order-2 lg:order-1"
            >
              <div className="aspect-square rounded-[3rem] overflow-hidden shadow-2xl">
                <img
                  src={culturePhotoUrl}
                  alt="Culture"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="order-1 lg:order-2"
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Cultural Hub</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white mb-10 leading-[1.1]">
                A Melting Pot of <span className="text-accent italic font-serif">Tradition</span>
              </h2>
              <p className="text-xl text-text-dark/70 dark:text-stone-400 mb-12 leading-relaxed font-light">
                Today, Shashemene is a bustling metropolis where Oromo traditions blend seamlessly with international influences. Our markets are among the most diverse in the country, offering everything from local agricultural products to global crafts.
              </p>
              <div className="flex gap-12">
                <div>
                  <div className="text-4xl font-display font-bold text-accent mb-2">15+</div>
                  <p className="text-xs text-stone-400 uppercase tracking-widest font-bold">Nationalities</p>
                </div>
                <div>
                  <div className="text-4xl font-display font-bold text-accent mb-2">120+</div>
                  <p className="text-xs text-stone-400 uppercase tracking-widest font-bold">Local Businesses</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-secondary text-text-dark text-center border-y border-stone-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-5xl md:text-7xl font-display font-bold mb-12 leading-tight">
            Be Part of Our <span className="text-accent italic font-serif">Future</span>
          </h2>
          <p className="text-stone-600 text-xl mb-16 font-light leading-relaxed">
            Whether you're a visitor, an investor, or a future resident, Shashemene welcomes you with open arms. Experience the pulse of progress.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <button className="px-12 py-5 bg-accent text-white rounded-full font-bold hover:bg-accent-hover transition-all">
              Contact Us
            </button>
            <button className="px-12 py-5 border border-stone-200 hover:bg-stone-50 rounded-full font-bold transition-all text-text-dark">
              Explore Services
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
