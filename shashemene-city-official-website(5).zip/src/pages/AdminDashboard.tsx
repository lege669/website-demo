import React, { useState, useEffect } from "react";
import { 
  LayoutDashboard, FileText, Users, Settings, Plus, Search, 
  Trash2, Edit, LogIn, LogOut, Loader2, X, Image as ImageIcon,
  Building2, Hotel, GraduationCap, Bus, Heart, Palmtree, Factory, Globe, Landmark, Mail, Eye, Star, Save, TrendingUp, ArrowUpRight, ArrowDownRight, MessageSquare, Newspaper, Camera
} from "lucide-react";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';
import { motion, AnimatePresence } from "motion/react";
import { 
  signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut, User as FirebaseUser 
} from "firebase/auth";
import { 
  collection, addDoc, getDocs, query, orderBy, limit, doc, getDoc, deleteDoc, updateDoc 
} from "firebase/firestore";
import { auth, db, handleFirestoreError, OperationType } from "../firebase";

const DEPARTMENTS = [
  "Water Bureau",
  "Revenue Bureau",
  "Finance Bureau",
  "Land Bureau",
  "Health Bureau",
  "Education Bureau",
  "Infrastructure Bureau",
  "Tourism Bureau",
  "City Administration",
  "General"
];

const COLORS = ['#FF6B00', '#444444', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899'];

const StatsOverview = ({ news, resources, messages, photos }: any) => {
  const data = [
    { name: 'Jan', news: 4, resources: 2, messages: 12 },
    { name: 'Feb', news: 7, resources: 5, messages: 18 },
    { name: 'Mar', news: news.length, resources: resources.length, messages: messages.length },
  ];

  const categoryData = [
    { name: 'Infrastructure', value: news.filter((n: any) => n.category === 'Infrastructure').length || 5 },
    { name: 'Culture', value: news.filter((n: any) => n.category === 'Culture').length || 3 },
    { name: 'Economy', value: news.filter((n: any) => n.category === 'Economy').length || 4 },
    { name: 'Community', value: news.filter((n: any) => n.category === 'Community').length || 6 },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total News', value: news.length, icon: Newspaper, color: 'text-blue-600', bg: 'bg-blue-50', trend: '+12%' },
          { label: 'Resources', value: resources.length, icon: Building2, color: 'text-accent', bg: 'bg-accent/10', trend: '+5%' },
          { label: 'Messages', value: messages.length, icon: MessageSquare, color: 'text-amber-600', bg: 'bg-amber-50', trend: '+24%' },
          { label: 'Gallery Photos', value: photos.length, icon: Camera, color: 'text-purple-600', bg: 'bg-purple-50', trend: '+8%' },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white dark:bg-primary p-6 rounded-3xl border border-secondary dark:border-white/10 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${stat.bg} dark:bg-white/5 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <div className="flex items-center gap-1 text-accent text-xs font-bold bg-accent/10 dark:bg-accent/20 px-2 py-1 rounded-full">
                <TrendingUp className="w-3 h-3" />
                {stat.trend}
              </div>
            </div>
            <div className="text-text-dark/60 dark:text-stone-400 text-sm font-medium">{stat.label}</div>
            <div className="text-3xl font-bold text-text-dark dark:text-white mt-1">{stat.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Activity Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-primary p-8 rounded-3xl border border-secondary dark:border-white/10 shadow-sm"
        >
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-text-dark dark:text-white">Content Activity</h3>
            <select className="bg-secondary dark:bg-white/5 border-none rounded-lg text-xs font-bold px-3 py-2 outline-none">
              <option>Last 3 Months</option>
              <option>Last 6 Months</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorNews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF6B00" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#FF6B00" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="news" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorNews)" />
                <Area type="monotone" dataKey="messages" stroke="#3b82f6" strokeWidth={3} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Category Distribution */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-primary p-8 rounded-3xl border border-secondary dark:border-white/10 shadow-sm"
        >
          <h3 className="text-lg font-bold text-text-dark dark:text-white mb-8">News by Category</h3>
          <div className="h-[300px] w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-col gap-4 ml-4">
              {categoryData.map((cat, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-xs font-medium text-text-dark/70 dark:text-stone-400">{cat.name}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [userDepartment, setUserDepartment] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [editUserForm, setEditUserForm] = useState({
    role: "user",
    department: ""
  });

  const [editingNews, setEditingNews] = useState<any>(null);
  const [showEditNewsModal, setShowEditNewsModal] = useState(false);
  const [editNewsForm, setEditNewsForm] = useState({
    title: "",
    content: "",
    category: "Infrastructure",
    image: "",
    department: "",
  });

  const [editingResource, setEditingResource] = useState<any>(null);
  const [showEditResourceModal, setShowEditResourceModal] = useState(false);
  const [editResourceForm, setEditResourceForm] = useState({
    name: "",
    category: "Infrastructure",
    description: "",
    image: "",
    location: "",
    website: "",
    contact: "",
    department: "",
  });

  const [viewingItem, setViewingItem] = useState<any>(null);
  const [showViewModal, setShowViewModal] = useState(false);

  const [news, setNews] = useState<any[]>([]);
  const [resources, setResources] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [photos, setPhotos] = useState<any[]>([]);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [siteSettings, setSiteSettings] = useState<any>(null);

  // Form States
  const [newsForm, setNewsForm] = useState({
    title: "",
    content: "",
    category: "Infrastructure",
    image: "",
    department: "",
  });

  const [resourceForm, setResourceForm] = useState({
    name: "",
    category: "Infrastructure",
    description: "",
    image: "",
    location: "",
    website: "",
    contact: "",
    department: "",
  });

  const [photoForm, setPhotoForm] = useState({
    url: "",
    section: "Hero",
    title: "",
    description: "",
    order: 0,
  });

  const [editingPhoto, setEditingPhoto] = useState<any>(null);
  const [showEditPhotoModal, setShowEditPhotoModal] = useState(false);
  const [editPhotoForm, setEditPhotoForm] = useState({
    url: "",
    section: "Hero",
    title: "",
    description: "",
    order: 0,
  });

  const [testimonialForm, setTestimonialForm] = useState({
    name: "",
    role: "",
    content: "",
    rating: 5,
    image: "",
  });

  const [editingTestimonial, setEditingTestimonial] = useState<any>(null);
  const [showEditTestimonialModal, setShowEditTestimonialModal] = useState(false);
  const [editTestimonialForm, setEditTestimonialForm] = useState({
    name: "",
    role: "",
    content: "",
    rating: 5,
    image: "",
  });

  const [settingsForm, setSettingsForm] = useState({
    aboutText: "",
    contactEmail: "",
    contactPhone: "",
    address: "",
    facebookUrl: "",
    twitterUrl: "",
    instagramUrl: "",
    heroTitle: "",
    heroSubtitle: "",
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, "users", currentUser.uid));
          let role = "user";
          let dept = null;

          if (userDoc.exists()) {
            role = userDoc.data().role;
            dept = userDoc.data().department;
          } else if (currentUser.email === "legesetsegaye41@gmail.com") {
            role = "super_admin";
          }

          setUserRole(role);
          setUserDepartment(dept);

          const isAnyAdmin = role === "super_admin" || role === "department_admin";

          if (isAnyAdmin) {
            // Fetch news
            const newsSnapshot = await getDocs(query(collection(db, "news"), orderBy("date", "desc")));
            let newsItems = newsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            if (role === "department_admin" && dept) {
              newsItems = newsItems.filter((item: any) => item.department === dept);
            }
            setNews(newsItems);

            // Fetch resources
            const resSnapshot = await getDocs(collection(db, "cityResources"));
            let resItems = resSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            if (role === "department_admin" && dept) {
              resItems = resItems.filter((item: any) => item.department === dept);
            }
            setResources(resItems);

            // Fetch photos
            const photosSnapshot = await getDocs(query(collection(db, "photos"), orderBy("order", "asc")));
            setPhotos(photosSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));

            // Fetch testimonials
            const testimonialsSnapshot = await getDocs(query(collection(db, "testimonials"), orderBy("date", "desc")));
            setTestimonials(testimonialsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));

            // Fetch settings
            const settingsSnapshot = await getDocs(collection(db, "siteSettings"));
            if (!settingsSnapshot.empty) {
              const settingsData = { id: settingsSnapshot.docs[0].id, ...settingsSnapshot.docs[0].data() };
              setSiteSettings(settingsData);
              setSettingsForm(settingsData as any);
            }

            if (role === "super_admin") {
              const usersSnapshot = await getDocs(collection(db, "users"));
              setUsers(usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));

              const msgsSnapshot = await getDocs(query(collection(db, "contactSubmissions"), orderBy("timestamp", "desc")));
              setMessages(msgsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            }
          }
        } catch (error) {
          console.error("Error checking admin status:", error);
          setUserRole("user");
        }
      } else {
        setUserRole(null);
        setUserDepartment(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const isSuperAdmin = userRole === "super_admin";
  const isDeptAdmin = userRole === "department_admin";
  const isAdmin = isSuperAdmin || isDeptAdmin;

  const handleCreateNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    
    setIsSubmitting(true);
    try {
      await addDoc(collection(db, "news"), {
        ...newsForm,
        department: isDeptAdmin ? userDepartment : (newsForm.department || newsForm.category),
        date: new Date().toISOString(),
        authorUid: user?.uid,
      });
      // Refresh news
      const newsSnapshot = await getDocs(query(collection(db, "news"), orderBy("date", "desc")));
      let newsItems = newsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      if (userRole === "department_admin" && userDepartment) {
        newsItems = newsItems.filter((item: any) => item.department === userDepartment);
      }
      setNews(newsItems);
      setShowCreateModal(false);
      setNewsForm({ title: "", content: "", category: "Infrastructure", image: "" });
      // Refresh logic could go here
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "news");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSuperAdmin || !editingUser) return;

    setIsSubmitting(true);
    try {
      await updateDoc(doc(db, "users", editingUser.id), editUserForm);
      setUsers(users.map(u => u.id === editingUser.id ? { ...u, ...editUserForm } : u));
      setShowEditUserModal(false);
      setEditingUser(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !editingNews) return;

    setIsSubmitting(true);
    try {
      const updatedData = {
        ...editNewsForm,
        department: isDeptAdmin ? userDepartment : (editNewsForm.department || editNewsForm.category)
      };
      await updateDoc(doc(db, "news", editingNews.id), updatedData);
      setNews(news.map(n => n.id === editingNews.id ? { ...n, ...updatedData } : n));
      setShowEditNewsModal(false);
      setEditingNews(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "news");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteNews = async (id: string) => {
    if (!isAdmin) return;
    if (confirm("Are you sure you want to delete this news post?")) {
      try {
        await deleteDoc(doc(db, "news", id));
        setNews(news.filter(n => n.id !== id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, "news");
      }
    }
  };

  const handleUpdateResource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !editingResource) return;

    setIsSubmitting(true);
    try {
      const updatedData = {
        ...editResourceForm,
        department: isDeptAdmin ? userDepartment : (editResourceForm.department || editResourceForm.category)
      };
      await updateDoc(doc(db, "cityResources", editingResource.id), updatedData);
      setResources(resources.map(r => r.id === editingResource.id ? { ...r, ...updatedData } : r));
      setShowEditResourceModal(false);
      setEditingResource(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "cityResources");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateResource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    
    setIsSubmitting(true);
    try {
      const finalResource = {
        ...resourceForm,
        department: isDeptAdmin ? userDepartment : (resourceForm.department || resourceForm.category)
      };
      const docRef = await addDoc(collection(db, "cityResources"), finalResource);
      setResources([...resources, { id: docRef.id, ...finalResource }]);
      setShowCreateModal(false);
      setResourceForm({
        name: "",
        category: "Infrastructure",
        description: "",
        image: "",
        location: "",
        website: "",
        contact: "",
        department: "",
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "cityResources");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreatePhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setIsSubmitting(true);
    try {
      const newPhoto = {
        ...photoForm,
        uploadedAt: new Date().toISOString(),
        authorUid: user?.uid,
      };
      const docRef = await addDoc(collection(db, "photos"), newPhoto);
      setPhotos([{ id: docRef.id, ...newPhoto }, ...photos]);
      setShowCreateModal(false);
      setPhotoForm({ url: "", section: "Hero", title: "", description: "", order: 0 });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "photos");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdatePhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !editingPhoto) return;
    setIsSubmitting(true);
    try {
      await updateDoc(doc(db, "photos", editingPhoto.id), editPhotoForm);
      setPhotos(photos.map(p => p.id === editingPhoto.id ? { ...p, ...editPhotoForm } : p));
      setShowEditPhotoModal(false);
      setEditingPhoto(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "photos");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeletePhoto = async (id: string) => {
    if (!isAdmin) return;
    if (confirm("Are you sure you want to delete this photo?")) {
      try {
        await deleteDoc(doc(db, "photos", id));
        setPhotos(photos.filter(p => p.id !== id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, "photos");
      }
    }
  };

  const handleCreateTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setIsSubmitting(true);
    try {
      const newTestimonial = {
        ...testimonialForm,
        date: new Date().toISOString(),
      };
      const docRef = await addDoc(collection(db, "testimonials"), newTestimonial);
      setTestimonials([{ id: docRef.id, ...newTestimonial }, ...testimonials]);
      setShowCreateModal(false);
      setTestimonialForm({ name: "", role: "", content: "", rating: 5, image: "" });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "testimonials");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !editingTestimonial) return;
    setIsSubmitting(true);
    try {
      await updateDoc(doc(db, "testimonials", editingTestimonial.id), editTestimonialForm);
      setTestimonials(testimonials.map(t => t.id === editingTestimonial.id ? { ...t, ...editTestimonialForm } : t));
      setShowEditTestimonialModal(false);
      setEditingTestimonial(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "testimonials");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteTestimonial = async (id: string) => {
    if (!isAdmin) return;
    if (confirm("Are you sure you want to delete this testimonial?")) {
      try {
        await deleteDoc(doc(db, "testimonials", id));
        setTestimonials(testimonials.filter(t => t.id !== id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, "testimonials");
      }
    }
  };

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setIsSubmitting(true);
    try {
      if (siteSettings?.id) {
        await updateDoc(doc(db, "siteSettings", siteSettings.id), settingsForm);
        setSiteSettings({ ...siteSettings, ...settingsForm });
      } else {
        const docRef = await addDoc(collection(db, "siteSettings"), settingsForm);
        setSiteSettings({ id: docRef.id, ...settingsForm });
      }
      alert("Settings updated successfully!");
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "siteSettings");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-primary">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="min-h-screen pt-32 flex flex-col items-center bg-white dark:bg-primary px-4">
        <div className="max-w-md w-full bg-white dark:bg-primary/50 p-12 rounded-[3rem] border border-secondary dark:border-white/10 text-center shadow-sm">
          <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <LogIn className="w-8 h-8 text-accent" />
          </div>
          <h1 className="text-3xl font-serif font-bold text-text-dark dark:text-white mb-4">Admin Access</h1>
          <p className="text-text-dark/70 dark:text-stone-400 mb-8">
            Please sign in with an authorized account to access the Shashemene City management portal.
          </p>
          <button
            onClick={handleLogin}
            className="w-full py-4 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center justify-center gap-2"
          >
            Sign in with Google
          </button>
          {user && !isAdmin && (
            <p className="mt-4 text-sm text-red-500 font-medium">
              Access Denied: Your account does not have administrator privileges.
            </p>
          )}
        </div>
      </div>
    );
  }

  const stats = [
    { label: "Total Residents", value: "158,432", change: "+2.4%", icon: Users },
    { label: "Active Permits", value: "1,240", change: "+12%", icon: FileText },
    { label: "Pending Requests", value: "45", change: "-5%", icon: LayoutDashboard },
  ];

  return (
    <div className="pt-16 min-h-screen bg-white dark:bg-primary flex transition-colors duration-300">
      {/* Sidebar */}
      <aside className="w-72 bg-white dark:bg-primary border-r border-secondary dark:border-white/10 hidden lg:block sticky top-16 h-[calc(100vh-64px)] overflow-y-auto">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10 px-2">
            <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center shadow-lg shadow-accent/20">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-text-dark dark:text-white">Admin Portal</h2>
              <p className="text-[10px] font-bold text-text-dark/40 uppercase tracking-widest">Management Console</p>
            </div>
          </div>

          <nav className="space-y-2">
            {[
              { id: "overview", label: "Overview", icon: LayoutDashboard, show: true },
              { id: "news", label: "News & Events", icon: FileText, show: true },
              { id: "resources", label: "City Resources", icon: Building2, show: true },
              { id: "photos", label: "Gallery Management", icon: ImageIcon, show: isSuperAdmin },
              { id: "testimonials", label: "Testimonials", icon: Star, show: isSuperAdmin },
              { id: "users", label: "User Management", icon: Users, show: isSuperAdmin },
              { id: "messages", label: "Inquiries", icon: Mail, show: isSuperAdmin },
              { id: "settings", label: "Site Settings", icon: Settings, show: isSuperAdmin },
            ].filter(item => item.show).map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200 ${
                  activeTab === item.id
                    ? "bg-accent text-white shadow-lg shadow-accent/20"
                    : "text-text-dark/60 dark:text-stone-400 hover:bg-secondary dark:hover:bg-white/5 hover:text-text-dark dark:hover:text-white"
                }`}
              >
                <item.icon className={`w-5 h-5 ${activeTab === item.id ? "text-white" : "text-text-dark/40"}`} />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="mt-12 pt-8 border-t border-secondary dark:border-white/10">
            <a 
              href="/"
              className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold text-text-dark/60 dark:text-stone-400 hover:bg-secondary dark:hover:bg-white/5 transition-all"
            >
              <Globe className="w-5 h-5" />
              Back to Website
            </a>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 mt-2 rounded-2xl text-sm font-bold text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-all"
            >
              <LogOut className="w-5 h-5" />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 lg:p-12 max-w-7xl mx-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-text-dark dark:text-white capitalize">
                {activeTab.replace('_', ' ')}
              </h1>
              <span className="px-3 py-1 bg-accent/10 dark:bg-accent/20 text-accent rounded-full text-[10px] font-bold uppercase tracking-widest">
                {userRole?.replace('_', ' ')}
              </span>
            </div>
            <p className="text-text-dark/60 dark:text-stone-400 text-sm font-medium">
              Welcome back, <span className="text-text-dark dark:text-stone-200 font-bold">{user.displayName || user.email}</span>
              {userDepartment && ` • ${userDepartment} Department`}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-text-dark/40" />
              <input 
                type="text" 
                placeholder="Search console..." 
                className="pl-10 pr-4 py-2.5 bg-white dark:bg-primary border border-secondary dark:border-white/10 rounded-xl text-sm outline-none focus:ring-2 focus:ring-accent/20 transition-all w-64"
              />
            </div>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="px-6 py-3 bg-accent text-white rounded-2xl text-sm font-bold hover:bg-accent-hover transition-all flex items-center gap-2 shadow-xl shadow-accent/10"
            >
              <Plus className="w-5 h-5" />
              {activeTab === "resources" ? "Add Resource" : activeTab === "photos" ? "Add Photo" : "Create New"}
            </button>
          </div>
        </header>

        {/* Edit User Modal */}
        {showEditUserModal && (
          <div className="fixed inset-0 bg-text-dark/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
            <div className="bg-white dark:bg-primary rounded-[2.5rem] w-full max-w-md overflow-hidden shadow-2xl border border-secondary dark:border-white/10">
              <div className="p-8 border-b border-secondary dark:border-white/10 flex items-center justify-between bg-white/50 dark:bg-primary/50">
                <h3 className="text-xl font-serif font-bold text-text-dark dark:text-white">Edit User Privileges</h3>
                <button onClick={() => setShowEditUserModal(false)} className="p-2 hover:bg-secondary dark:hover:bg-white/5 rounded-full transition-colors">
                  <X className="w-5 h-5 text-text-dark/40" />
                </button>
              </div>
              <form onSubmit={handleUpdateUser} className="p-8 space-y-6">
                <div>
                  <label className="block text-xs font-bold text-text-dark/40 uppercase tracking-widest mb-2">User</label>
                  <p className="text-text-dark dark:text-white font-medium">{editingUser?.displayName} ({editingUser?.email})</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-dark/40 uppercase tracking-widest mb-2">Role</label>
                  <select
                    value={editUserForm.role}
                    onChange={(e) => setEditUserForm({ ...editUserForm, role: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-secondary dark:border-white/10 bg-white dark:bg-primary text-text-dark dark:text-white focus:ring-2 focus:ring-accent outline-none transition-all"
                  >
                    <option value="user">User</option>
                    <option value="department_admin">Department Admin</option>
                    <option value="super_admin">Super Admin</option>
                  </select>
                </div>
                {editUserForm.role === "department_admin" && (
                  <div>
                    <label className="block text-xs font-bold text-text-dark/40 uppercase tracking-widest mb-2">Department</label>
                    <select
                      value={editUserForm.department}
                      onChange={(e) => setEditUserForm({ ...editUserForm, department: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-secondary dark:border-white/10 bg-white dark:bg-primary text-text-dark dark:text-white focus:ring-2 focus:ring-accent outline-none transition-all"
                      required
                    >
                      <option value="">Select Department</option>
                      {DEPARTMENTS.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                )}
                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditUserModal(false)}
                    className="flex-1 py-4 border border-secondary dark:border-white/10 text-text-dark/60 dark:text-stone-400 rounded-xl font-bold hover:bg-secondary dark:hover:bg-white/5 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-4 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? "Updating..." : "Update User"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit News Modal */}
        {showEditNewsModal && (
          <div className="fixed inset-0 bg-text-dark/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <h3 className="text-xl font-bold text-stone-900">Edit News Post</h3>
                <button onClick={() => setShowEditNewsModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>
              <form onSubmit={handleUpdateNews} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Headline</label>
                  <input
                    required
                    type="text"
                    value={editNewsForm.title}
                    onChange={(e) => setEditNewsForm({ ...editNewsForm, title: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-accent/20"
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Category</label>
                    <select
                      value={editNewsForm.category}
                      onChange={(e) => setEditNewsForm({ ...editNewsForm, category: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-accent/20"
                    >
                      <option>Infrastructure</option>
                      <option>Culture</option>
                      <option>Economy</option>
                      <option>Community</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Department</label>
                    <select
                      value={isDeptAdmin ? userDepartment || "" : editNewsForm.department}
                      disabled={isDeptAdmin}
                      onChange={(e) => setEditNewsForm({ ...editNewsForm, department: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 disabled:opacity-50"
                    >
                      <option value="">Select Department</option>
                      {DEPARTMENTS.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Image URL</label>
                  <input
                    type="url"
                    value={editNewsForm.image}
                    onChange={(e) => setEditNewsForm({ ...editNewsForm, image: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Content</label>
                  <textarea
                    required
                    rows={6}
                    value={editNewsForm.content}
                    onChange={(e) => setEditNewsForm({ ...editNewsForm, content: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                  ></textarea>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditNewsModal(false)}
                    className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Resource Modal */}
        {showEditResourceModal && (
          <div className="fixed inset-0 bg-text-dark/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <h3 className="text-xl font-bold text-stone-900">Edit City Resource</h3>
                <button onClick={() => setShowEditResourceModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>
              <form onSubmit={handleUpdateResource} className="p-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Resource Name</label>
                    <input
                      required
                      type="text"
                      value={editResourceForm.name}
                      onChange={(e) => setEditResourceForm({ ...editResourceForm, name: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Category</label>
                    <select
                      value={editResourceForm.category}
                      onChange={(e) => setEditResourceForm({ ...editResourceForm, category: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    >
                      <option value="Infrastructure">Infrastructure</option>
                      <option value="Projects">Projects</option>
                      <option value="Production">Production</option>
                      <option value="Hotels">Hotels</option>
                      <option value="Education">Education</option>
                      <option value="Accommodation">Accommodation</option>
                      <option value="Transportation">Transportation</option>
                      <option value="CommunityServices">Community Services</option>
                      <option value="Culture">Culture</option>
                      <option value="Industry">Industry</option>
                      <option value="NGO">NGO</option>
                      <option value="GovernmentService">Government Service</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Department</label>
                  <select
                    value={isDeptAdmin ? userDepartment || "" : editResourceForm.department}
                    disabled={isDeptAdmin}
                    onChange={(e) => setEditResourceForm({ ...editResourceForm, department: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 disabled:opacity-50"
                  >
                    <option value="">Select Department</option>
                    {DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Description</label>
                  <textarea
                    required
                    rows={4}
                    value={editResourceForm.description}
                    onChange={(e) => setEditResourceForm({ ...editResourceForm, description: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                  ></textarea>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Image URL</label>
                    <input
                      type="url"
                      value={editResourceForm.image}
                      onChange={(e) => setEditResourceForm({ ...editResourceForm, image: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Location</label>
                    <input
                      type="text"
                      value={editResourceForm.location}
                      onChange={(e) => setEditResourceForm({ ...editResourceForm, location: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditResourceModal(false)}
                    className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Testimonial Modal */}
        {showEditTestimonialModal && editingTestimonial && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-stone-100 flex items-center justify-between">
                <h2 className="text-xl font-bold text-stone-900">Edit Testimonial</h2>
                <button onClick={() => setShowEditTestimonialModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateTestimonial} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Author Name</label>
                  <input
                    required
                    type="text"
                    value={testimonialForm.authorName}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, authorName: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Author Role/Title</label>
                  <input
                    required
                    type="text"
                    value={testimonialForm.authorRole}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, authorRole: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Content</label>
                  <textarea
                    required
                    rows={4}
                    value={testimonialForm.content}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, content: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                  ></textarea>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Rating (1-5)</label>
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={testimonialForm.rating}
                      onChange={(e) => setTestimonialForm({ ...testimonialForm, rating: parseInt(e.target.value) || 5 })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Author Image URL (Optional)</label>
                    <input
                      type="url"
                      value={testimonialForm.authorImage}
                      onChange={(e) => setTestimonialForm({ ...testimonialForm, authorImage: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditTestimonialModal(false)}
                    className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Update Testimonial"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {/* Edit Photo Modal */}
        {showEditPhotoModal && (
          <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <h3 className="text-xl font-bold text-stone-900">Edit Website Photo</h3>
                <button onClick={() => setShowEditPhotoModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>
              <form onSubmit={handleUpdatePhoto} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Image URL</label>
                  <input
                    required
                    type="url"
                    value={editPhotoForm.url}
                    onChange={(e) => setEditPhotoForm({ ...editPhotoForm, url: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Website Section</label>
                    <select
                      required
                      value={editPhotoForm.section}
                      onChange={(e) => setEditPhotoForm({ ...editPhotoForm, section: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    >
                      <option value="Hero">Hero</option>
                      <option value="About">About</option>
                      <option value="Services">Services</option>
                      <option value="Portfolio">Portfolio</option>
                      <option value="Blog">Blog</option>
                      <option value="Contact">Contact</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Display Order</label>
                    <input
                      type="number"
                      value={editPhotoForm.order}
                      onChange={(e) => setEditPhotoForm({ ...editPhotoForm, order: parseInt(e.target.value) || 0 })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Title (Optional)</label>
                  <input
                    type="text"
                    value={editPhotoForm.title}
                    onChange={(e) => setEditPhotoForm({ ...editPhotoForm, title: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Description (Optional)</label>
                  <textarea
                    rows={3}
                    value={editPhotoForm.description}
                    onChange={(e) => setEditPhotoForm({ ...editPhotoForm, description: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                    placeholder="Describe the photo..."
                  ></textarea>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditPhotoModal(false)}
                    className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* View Modal */}
        {showViewModal && viewingItem && (
          <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <h3 className="text-xl font-bold text-stone-900">
                  {viewingItem.type === 'news' ? 'News Details' : viewingItem.type === 'resource' ? 'Resource Details' : 'Message Details'}
                </h3>
                <button onClick={() => setShowViewModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>
              <div className="p-8 space-y-6">
                {viewingItem.image && (
                  <div className="aspect-video rounded-2xl overflow-hidden border border-stone-200">
                    <img src={viewingItem.image} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                )}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">
                      {viewingItem.type === 'news' ? 'Headline' : viewingItem.type === 'resource' ? 'Name' : 'Subject'}
                    </h4>
                    <p className="text-xl font-bold text-stone-900">
                      {viewingItem.title || viewingItem.name || viewingItem.subject}
                    </p>
                  </div>
                  
                  {viewingItem.type === 'message' && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">From</h4>
                        <p className="text-stone-900 font-medium">{viewingItem.name}</p>
                        <p className="text-stone-500 text-sm">{viewingItem.email}</p>
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">Date</h4>
                        <p className="text-stone-900 font-medium">{new Date(viewingItem.timestamp).toLocaleString()}</p>
                      </div>
                    </div>
                  )}

                  <div>
                    <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">
                      {viewingItem.type === 'message' ? 'Message' : 'Content/Description'}
                    </h4>
                    <p className="text-stone-600 whitespace-pre-wrap leading-relaxed">
                      {viewingItem.content || viewingItem.description || viewingItem.message}
                    </p>
                  </div>

                  {viewingItem.type === 'resource' && (
                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-stone-100">
                      <div>
                        <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">Location</h4>
                        <p className="text-stone-900">{viewingItem.location || 'N/A'}</p>
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">Category</h4>
                        <p className="text-stone-900">{viewingItem.category}</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex justify-end pt-4">
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Create Modals */}
        {showCreateModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-text-dark/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-stone-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <h2 className="text-xl font-bold text-stone-900">
                  {activeTab === "resources" ? "Add City Resource" : activeTab === "photos" ? "Add Website Photo" : activeTab === "testimonials" ? "Add Testimonial" : "Create New News Post"}
                </h2>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setShowCreateModal(false)} 
                    className="px-4 py-2 text-sm font-bold text-stone-500 hover:text-accent transition-colors"
                  >
                    Cancel
                  </button>
                  <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-stone-50 rounded-lg transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {activeTab === "resources" ? (
                <form onSubmit={handleCreateResource} className="p-8 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Resource Name</label>
                      <input
                        required
                        type="text"
                        value={resourceForm.name}
                        onChange={(e) => setResourceForm({ ...resourceForm, name: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="e.g. Shashemene University"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Category</label>
                      <select
                        value={resourceForm.category}
                        onChange={(e) => setResourceForm({ ...resourceForm, category: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      >
                        <option value="Infrastructure">Infrastructure</option>
                        <option value="Projects">Projects</option>
                        <option value="Production">Production</option>
                        <option value="Hotels">Hotels</option>
                        <option value="Education">Education</option>
                        <option value="Accommodation">Accommodation</option>
                        <option value="Transportation">Transportation</option>
                        <option value="CommunityServices">Community Services</option>
                        <option value="Culture">Culture</option>
                        <option value="Industry">Industry</option>
                        <option value="NGO">NGO</option>
                        <option value="GovernmentService">Government Service</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Department</label>
                    <select
                      value={isDeptAdmin ? userDepartment || "" : resourceForm.department}
                      disabled={isDeptAdmin}
                      onChange={(e) => setResourceForm({ ...resourceForm, department: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 disabled:opacity-50"
                    >
                      <option value="">Select Department</option>
                      {DEPARTMENTS.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                    {isDeptAdmin && <p className="text-[10px] text-stone-400 italic">Fixed to your assigned department</p>}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Description</label>
                    <textarea
                      required
                      rows={4}
                      value={resourceForm.description}
                      onChange={(e) => setResourceForm({ ...resourceForm, description: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                      placeholder="Describe the resource..."
                    ></textarea>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Image URL</label>
                      <input
                        type="url"
                        value={resourceForm.image}
                        onChange={(e) => setResourceForm({ ...resourceForm, image: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Location/Address</label>
                      <input
                        type="text"
                        value={resourceForm.location}
                        onChange={(e) => setResourceForm({ ...resourceForm, location: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="e.g. Main St, Shashemene"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Website URL</label>
                      <input
                        type="url"
                        value={resourceForm.website}
                        onChange={(e) => setResourceForm({ ...resourceForm, website: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Contact Info</label>
                      <input
                        type="text"
                        value={resourceForm.contact}
                        onChange={(e) => setResourceForm({ ...resourceForm, contact: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="e.g. +251..."
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowCreateModal(false)}
                      className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      disabled={isSubmitting}
                      type="submit"
                      className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Add Resource"}
                    </button>
                  </div>
                </form>
              ) : activeTab === "photos" ? (
                <form onSubmit={handleCreatePhoto} className="p-8 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Image URL</label>
                      <input
                        required
                        type="url"
                        value={photoForm.url}
                        onChange={(e) => setPhotoForm({ ...photoForm, url: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Section</label>
                      <select
                        value={photoForm.section}
                        onChange={(e) => setPhotoForm({ ...photoForm, section: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      >
                        <option value="Hero">Hero</option>
                        <option value="About">About</option>
                        <option value="Services">Services</option>
                        <option value="Portfolio">Portfolio</option>
                        <option value="Blog">Blog</option>
                        <option value="Contact">Contact</option>
                        <option value="Testimonials">Testimonials</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Title (Optional)</label>
                    <input
                      type="text"
                      value={photoForm.title}
                      onChange={(e) => setPhotoForm({ ...photoForm, title: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      placeholder="e.g. City Hall at Night"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Description (Optional)</label>
                    <textarea
                      rows={3}
                      value={photoForm.description}
                      onChange={(e) => setPhotoForm({ ...photoForm, description: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                      placeholder="Describe the photo..."
                    ></textarea>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Display Order</label>
                    <input
                      type="number"
                      value={photoForm.order}
                      onChange={(e) => setPhotoForm({ ...photoForm, order: parseInt(e.target.value) || 0 })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>

                  {photoForm.url && (
                    <div className="mt-4 p-4 bg-stone-50 rounded-2xl border border-stone-200">
                      <p className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-2">Preview</p>
                      <img 
                        src={photoForm.url} 
                        alt="Preview" 
                        className="w-full h-48 object-cover rounded-xl"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}

                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowCreateModal(false)}
                      className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      disabled={isSubmitting}
                      type="submit"
                      className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Add Photo"}
                    </button>
                  </div>
                </form>
              ) : activeTab === "testimonials" ? (
                <form onSubmit={handleCreateTestimonial} className="p-8 space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Author Name</label>
                    <input
                      required
                      type="text"
                      value={testimonialForm.authorName}
                      onChange={(e) => setTestimonialForm({ ...testimonialForm, authorName: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      placeholder="e.g. John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Author Role/Title</label>
                    <input
                      required
                      type="text"
                      value={testimonialForm.authorRole}
                      onChange={(e) => setTestimonialForm({ ...testimonialForm, authorRole: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      placeholder="e.g. CEO, Tech Corp"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Content</label>
                    <textarea
                      required
                      rows={4}
                      value={testimonialForm.content}
                      onChange={(e) => setTestimonialForm({ ...testimonialForm, content: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                      placeholder="Enter testimonial content..."
                    ></textarea>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Rating (1-5)</label>
                      <input
                        type="number"
                        min="1"
                        max="5"
                        value={testimonialForm.rating}
                        onChange={(e) => setTestimonialForm({ ...testimonialForm, rating: parseInt(e.target.value) || 5 })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Author Image URL (Optional)</label>
                      <input
                        type="url"
                        value={testimonialForm.authorImage}
                        onChange={(e) => setTestimonialForm({ ...testimonialForm, authorImage: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://..."
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowCreateModal(false)}
                      className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      disabled={isSubmitting}
                      type="submit"
                      className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Add Testimonial"}
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleCreateNews} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Headline</label>
                  <input
                    required
                    type="text"
                    value={newsForm.title}
                    onChange={(e) => setNewsForm({ ...newsForm, title: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    placeholder="Enter news headline..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Category</label>
                    <select
                      value={newsForm.category}
                      onChange={(e) => setNewsForm({ ...newsForm, category: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                    >
                      <option>Infrastructure</option>
                      <option>Culture</option>
                      <option>Economy</option>
                      <option>Community</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-stone-700">Department</label>
                    <select
                      value={isDeptAdmin ? userDepartment || "" : newsForm.department}
                      disabled={isDeptAdmin}
                      onChange={(e) => setNewsForm({ ...newsForm, department: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 disabled:opacity-50"
                    >
                      <option value="">Select Department</option>
                      {DEPARTMENTS.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Image URL</label>
                  <div className="relative">
                    <ImageIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input
                      type="url"
                      value={newsForm.image}
                      onChange={(e) => setNewsForm({ ...newsForm, image: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      placeholder="https://..."
                    />
                  </div>
                  {newsForm.image && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-3 relative aspect-video rounded-xl overflow-hidden border border-stone-200 bg-stone-100 group"
                    >
                      <img 
                        src={newsForm.image} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://picsum.photos/seed/error/600/400?blur=2";
                        }}
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="text-white text-xs font-bold bg-black/40 px-3 py-1 rounded-full backdrop-blur-md">
                          Image Preview
                        </span>
                      </div>
                    </motion.div>
                  )}
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-stone-700">Content</label>
                  <textarea
                    required
                    rows={6}
                    value={newsForm.content}
                    onChange={(e) => setNewsForm({ ...newsForm, content: e.target.value })}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                    placeholder="Write the news content here..."
                  ></textarea>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-6 py-3 text-stone-600 font-medium hover:bg-stone-50 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl font-bold hover:bg-accent-hover transition-colors flex items-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Publish Post"}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      )}

        {/* Dynamic Content Based on Tabs */}
        {activeTab === "overview" && (
          <div className="space-y-12">
            <StatsOverview news={news} resources={resources} messages={messages} photos={photos} />

            {/* Recent Content Table */}
            <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-100 dark:border-stone-800 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-stone-900 dark:text-white">Recent News Posts</h3>
                  <p className="text-sm text-stone-500 dark:text-stone-400">Latest updates published to the website</p>
                </div>
                <button 
                  onClick={() => setActiveTab("news")}
                  className="px-4 py-2 text-sm text-accent font-bold hover:bg-accent/10 dark:hover:bg-accent/20 rounded-xl transition-colors"
                >
                  View All
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-white/50 dark:bg-stone-800/50 text-xs font-bold text-stone-400 dark:text-stone-500 uppercase tracking-widest">
                      <th className="px-8 py-5">Title</th>
                      <th className="px-8 py-5">Category</th>
                      <th className="px-8 py-5">Date</th>
                      <th className="px-8 py-5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                    {news.slice(0, 5).map((item) => (
                      <tr key={item.id} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/30 transition-colors group">
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-4">
                            {item.image && (
                              <img src={item.image} className="w-10 h-10 rounded-lg object-cover" alt="" />
                            )}
                            <span className="text-sm font-bold text-stone-900 dark:text-stone-100 group-hover:text-accent transition-colors">{item.title}</span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <span className="text-xs font-bold px-2 py-1 bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 rounded-md uppercase tracking-wider">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-sm text-stone-500 dark:text-stone-400">{new Date(item.date).toLocaleDateString()}</td>
                        <td className="px-8 py-5 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button 
                              onClick={() => {
                                setViewingItem({ ...item, type: 'news' });
                                setShowViewModal(true);
                              }}
                              className="p-2 text-stone-400 hover:text-accent transition-colors"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => {
                                setEditingNews(item);
                                setEditNewsForm({
                                  title: item.title,
                                  content: item.content,
                                  category: item.category,
                                  image: item.image,
                                  department: item.department || ""
                                });
                                setShowEditNewsModal(true);
                              }}
                              className="p-2 text-stone-400 hover:text-accent transition-colors"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteNews(item.id)}
                              className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {news.length === 0 && (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-stone-500">
                          No news posts found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "news" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-bold text-stone-900">News & Events Management</h3>
              <span className="text-sm text-stone-500">{news.length} posts</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Department</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {news.map((item) => (
                    <tr key={item.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-stone-900">{item.title}</td>
                      <td className="px-6 py-4 text-sm text-stone-500">{item.category}</td>
                      <td className="px-6 py-4 text-sm text-stone-500">{item.department || "General"}</td>
                      <td className="px-6 py-4 text-sm text-stone-500">{new Date(item.date).toLocaleDateString()}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              setViewingItem({ ...item, type: 'news' });
                              setShowViewModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => {
                              setEditingNews(item);
                              setEditNewsForm({
                                title: item.title,
                                content: item.content,
                                category: item.category,
                                image: item.image,
                                department: item.department || ""
                              });
                              setShowEditNewsModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteNews(item.id)}
                            className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "resources" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-bold text-stone-900">City Resources Directory</h3>
              <div className="flex items-center gap-2">
                <span className="text-sm text-stone-500">{resources.length} items</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Name</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Location</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {resources.map((res) => (
                    <tr key={res.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-stone-900">{res.name}</td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold px-2 py-1 rounded-full bg-stone-100 text-stone-600">
                          {res.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-stone-500">{res.location || "N/A"}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              setViewingItem({ ...res, type: 'resource' });
                              setShowViewModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => {
                              setEditingResource(res);
                              setEditResourceForm({
                                name: res.name,
                                category: res.category,
                                description: res.description,
                                image: res.image,
                                location: res.location,
                                website: res.website,
                                contact: res.contact,
                                department: res.department || ""
                              });
                              setShowEditResourceModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={async () => {
                              if (confirm("Are you sure you want to delete this resource?")) {
                                try {
                                  await deleteDoc(doc(db, "cityResources", res.id));
                                  setResources(resources.filter(r => r.id !== res.id));
                                } catch (error) {
                                  handleFirestoreError(error, OperationType.DELETE, "cityResources");
                                }
                              }
                            }}
                            className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {resources.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-stone-500">
                        No resources found. Add your first city resource!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "photos" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-bold text-stone-900">Website Photo Management</h3>
              <span className="text-sm text-stone-500">{photos.length} photos</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Preview</th>
                    <th className="px-6 py-4">Section</th>
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Order</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {photos.map((photo) => (
                    <tr key={photo.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <img 
                          src={photo.url} 
                          alt={photo.title} 
                          className="w-12 h-12 object-cover rounded-lg border border-stone-200"
                          referrerPolicy="no-referrer"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold px-2 py-1 rounded-full bg-orange-50 text-orange-700">
                          {photo.section}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-stone-900">{photo.title || "Untitled"}</td>
                      <td className="px-6 py-4 text-sm text-stone-500">{photo.order}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              setEditingPhoto(photo);
                              setEditPhotoForm({
                                url: photo.url,
                                section: photo.section,
                                title: photo.title || "",
                                description: photo.description || "",
                                order: photo.order || 0,
                              });
                              setShowEditPhotoModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeletePhoto(photo.id)}
                            className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {photos.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-stone-500">
                        No photos found. Add some to see them here.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "testimonials" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-bold text-stone-900">Testimonials Management</h3>
              <span className="text-sm text-stone-500">{testimonials.length} testimonials</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Author</th>
                    <th className="px-6 py-4">Role</th>
                    <th className="px-6 py-4">Rating</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {testimonials.map((item) => (
                    <tr key={item.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          {item.authorImage ? (
                            <img 
                              src={item.authorImage} 
                              alt={item.authorName} 
                              className="w-8 h-8 rounded-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 text-xs font-bold">
                              {item.authorName.charAt(0)}
                            </div>
                          )}
                          <span className="text-sm font-medium text-stone-900">{item.authorName}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-stone-500">{item.authorRole}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`w-3 h-3 ${i < item.rating ? "text-amber-400 fill-amber-400" : "text-stone-200"}`} 
                            />
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              setEditingTestimonial(item);
                              setTestimonialForm({
                                authorName: item.authorName,
                                authorRole: item.authorRole,
                                content: item.content,
                                rating: item.rating,
                                authorImage: item.authorImage || ""
                              });
                              setShowEditTestimonialModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteTestimonial(item.id)}
                            className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {testimonials.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-stone-500">
                        No testimonials found. Add your first testimonial!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="max-w-4xl">
            <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between">
                <h3 className="font-bold text-stone-900">Site Settings</h3>
                <button
                  onClick={handleUpdateSettings}
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-text-dark text-white rounded-xl font-bold hover:bg-text-dark/90 transition-colors flex items-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4" /> Save Settings</>}
                </button>
              </div>
              <div className="p-8 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h4 className="text-sm font-bold text-stone-400 uppercase tracking-widest">General Information</h4>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Site Name</label>
                      <input
                        type="text"
                        value={settingsForm.siteName}
                        onChange={(e) => setSettingsForm({ ...settingsForm, siteName: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Site Description</label>
                      <textarea
                        rows={3}
                        value={settingsForm.siteDescription}
                        onChange={(e) => setSettingsForm({ ...settingsForm, siteDescription: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 resize-none"
                      ></textarea>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-bold text-stone-400 uppercase tracking-widest">Contact Details</h4>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Contact Email</label>
                      <input
                        type="email"
                        value={settingsForm.contactEmail}
                        onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Contact Phone</label>
                      <input
                        type="text"
                        value={settingsForm.contactPhone}
                        onChange={(e) => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Address</label>
                      <input
                        type="text"
                        value={settingsForm.address}
                        onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-stone-400 uppercase tracking-widest">Social Media Links</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Facebook</label>
                      <input
                        type="url"
                        value={settingsForm.facebook}
                        onChange={(e) => setSettingsForm({ ...settingsForm, facebook: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://facebook.com/..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Twitter</label>
                      <input
                        type="url"
                        value={settingsForm.twitter}
                        onChange={(e) => setSettingsForm({ ...settingsForm, twitter: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://twitter.com/..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-stone-700">Instagram</label>
                      <input
                        type="url"
                        value={settingsForm.instagram}
                        onChange={(e) => setSettingsForm({ ...settingsForm, instagram: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20"
                        placeholder="https://instagram.com/..."
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100">
              <h3 className="font-bold text-stone-900">User Management</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                    <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                      <th className="px-6 py-4">Name</th>
                      <th className="px-6 py-4">Email</th>
                      <th className="px-6 py-4">Role</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-stone-50/50 transition-colors">
                        <td className="px-6 py-4 text-sm font-medium text-stone-900">{u.displayName || "Anonymous"}</td>
                        <td className="px-6 py-4 text-sm text-stone-500">{u.email}</td>
                        <td className="px-6 py-4">
                          <span className={`text-xs font-bold px-2 py-1 rounded-full ${u.role === "super_admin" ? "bg-accent/10 text-accent" : "bg-stone-100 text-stone-600"}`}>
                            {u.role} {u.department ? `(${u.department})` : ''}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => {
                              setEditingUser(u);
                              setEditUserForm({
                                role: u.role || "user",
                                department: u.department || ""
                              });
                              setShowEditUserModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "messages" && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100">
              <h3 className="font-bold text-stone-900">Contact Form Messages</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50 text-xs font-semibold text-stone-500 uppercase tracking-wider">
                    <th className="px-6 py-4">Sender</th>
                    <th className="px-6 py-4">Subject</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {messages.map((msg) => (
                    <tr key={msg.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-stone-900">{msg.name}</div>
                        <div className="text-xs text-stone-500">{msg.email}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-stone-500">{msg.subject}</td>
                      <td className="px-6 py-4 text-sm text-stone-500">{new Date(msg.timestamp).toLocaleDateString()}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              setViewingItem({ ...msg, type: 'message' });
                              setShowViewModal(true);
                            }}
                            className="p-2 text-stone-400 hover:text-accent transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={async () => {
                              if (confirm("Delete this message?")) {
                                try {
                                  await deleteDoc(doc(db, "contactSubmissions", msg.id));
                                  setMessages(messages.filter(m => m.id !== msg.id));
                                } catch (error) {
                                  handleFirestoreError(error, OperationType.DELETE, "contactSubmissions");
                                }
                              }
                            }}
                            className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
