import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Send, Globe, CheckCircle2, Loader2, Camera, ArrowRight, MessageSquare, Clock } from "lucide-react";
import { collection, addDoc, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";

const countries = [
  { code: "ET", name: "Ethiopia" },
  { code: "US", name: "United States" },
  { code: "GB", name: "United Kingdom" },
  { code: "JM", name: "Jamaica" },
  { code: "CA", name: "Canada" },
  { code: "KE", name: "Kenya" },
  { code: "ZA", name: "South Africa" },
];

export default function Contact() {
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [contactPhotos, setContactPhotos] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    country: "ET",
    subject: "",
    message: "",
  });

  useEffect(() => {
    const q = query(
      collection(db, "photos"),
      where("section", "==", "Contact"),
      orderBy("order", "asc")
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedPhotos = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setContactPhotos(fetchedPhotos);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Contact");
    });
    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, "contactSubmissions"), {
        ...formData,
        timestamp: new Date().toISOString(),
      });
      setSubmitted(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "contactSubmissions");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="pt-40 pb-40 flex items-center justify-center min-h-screen">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          className="text-center max-w-2xl p-16 bg-white dark:bg-primary rounded-[4rem] border border-secondary dark:border-white/5 shadow-2xl"
        >
          <div className="w-24 h-24 bg-accent rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-xl shadow-accent/20">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-5xl font-display font-bold text-text-dark dark:text-white mb-6">Message Received!</h2>
          <p className="text-xl text-text-dark/60 dark:text-stone-400 mb-12 font-light leading-relaxed">
            Thank you for reaching out. Our team will review your inquiry and get back to you within 24 business hours.
          </p>
          <button
            onClick={() => setSubmitted(false)}
            className="px-12 py-5 bg-accent text-white rounded-full font-bold hover:bg-accent-hover transition-all shadow-lg shadow-accent/20"
          >
            Send Another Message
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-40 pb-24 bg-white dark:bg-primary/30 border-b border-secondary dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Get in Touch</span>
              <h1 className="text-6xl md:text-8xl font-display font-bold text-text-dark dark:text-white mb-8 leading-[1.1]">
                Let's Start a <span className="text-accent italic font-serif">Conversation</span>
              </h1>
              <p className="text-xl text-text-dark/70 dark:text-stone-400 leading-relaxed font-light">
                Whether you're a local resident, a global citizen, or an investor, we're here to listen and support your journey in Shashemene.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-24">
            {/* Contact Info */}
            <div className="lg:col-span-5 space-y-16">
              <div>
                <h2 className="text-4xl font-display font-bold text-text-dark dark:text-white mb-10">Contact Information</h2>
                <div className="space-y-10">
                  {[
                    { icon: MapPin, title: "Our Location", detail: "City Hall, Main Road, Shashemene, Oromia, Ethiopia", color: "bg-accent/10 text-accent" },
                    { icon: Phone, title: "Call Center", detail: "+251 46 123 4567", color: "bg-primary/10 text-primary dark:text-accent dark:bg-accent/10" },
                    { icon: Mail, title: "Email Support", detail: "info@shashemene.gov.et", color: "bg-accent/10 text-accent" },
                    { icon: Clock, title: "Working Hours", detail: "Mon - Fri: 8:30 AM - 5:30 PM", color: "bg-accent/10 text-accent" },
                  ].map((item, idx) => (
                    <motion.div 
                      key={idx} 
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex gap-6 group"
                    >
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110 group-hover:rotate-6 ${item.color}`}>
                        <item.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-display font-bold tracking-widest uppercase text-stone-400 mb-2">{item.title}</h3>
                        <p className="text-xl font-medium text-text-dark dark:text-white">{item.detail}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="p-10 bg-white dark:bg-primary rounded-[3rem] border border-secondary dark:border-white/5">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-text-dark dark:text-white">Live Chat Support</h3>
                </div>
                <p className="text-text-dark/60 dark:text-stone-400 font-light mb-8">
                  Need immediate help? Our digital assistants are ready to guide you through our public services.
                </p>
                <button className="w-full py-4 bg-primary dark:bg-white text-white dark:text-primary rounded-2xl font-bold hover:bg-accent dark:hover:bg-accent dark:hover:text-white transition-all">
                  Start Live Chat
                </button>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-7">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white dark:bg-primary p-10 md:p-16 rounded-[4rem] border border-secondary dark:border-white/5 shadow-2xl shadow-stone-200/50 dark:shadow-none"
              >
                <h2 className="text-3xl font-display font-bold text-text-dark dark:text-white mb-10">Send a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-xs font-display font-bold tracking-widest uppercase text-stone-400 ml-2">Full Name</label>
                      <input
                        required
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-6 py-5 bg-secondary dark:bg-stone-800 border border-secondary dark:border-white/5 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all text-text-dark dark:text-white"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-xs font-display font-bold tracking-widest uppercase text-stone-400 ml-2">Email Address</label>
                      <input
                        required
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-6 py-5 bg-secondary dark:bg-stone-800 border border-secondary dark:border-white/5 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all text-text-dark dark:text-white"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-xs font-display font-bold tracking-widest uppercase text-stone-400 ml-2">Country</label>
                      <select
                        value={formData.country}
                        onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                        className="w-full px-6 py-5 bg-white dark:bg-stone-800 border border-secondary dark:border-white/5 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all text-text-dark dark:text-white appearance-none"
                      >
                        {countries.map((c) => (
                          <option key={c.code} value={c.code}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-3">
                      <label className="text-xs font-display font-bold tracking-widest uppercase text-stone-400 ml-2">Subject</label>
                      <input
                        required
                        type="text"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-6 py-5 bg-secondary dark:bg-stone-800 border border-secondary dark:border-white/5 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all text-text-dark dark:text-white"
                        placeholder="How can we help?"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-display font-bold tracking-widest uppercase text-stone-400 ml-2">Your Message</label>
                    <textarea
                      required
                      rows={6}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-6 py-5 bg-white dark:bg-stone-800 border border-secondary dark:border-white/5 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all resize-none text-text-dark dark:text-white"
                      placeholder="Tell us more about your inquiry..."
                    ></textarea>
                  </div>

                  <button
                    disabled={loading}
                    type="submit"
                    className="w-full py-6 bg-accent text-white rounded-2xl font-bold hover:bg-accent-hover transition-all flex items-center justify-center gap-3 disabled:opacity-50 shadow-xl shadow-accent/20"
                  >
                    {loading ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        Send Message
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="h-[600px] w-full bg-secondary dark:bg-stone-800 relative overflow-hidden">
        <div className="absolute inset-0 grayscale dark:invert opacity-50">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15844.123456789!2d38.59!3d7.19!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x17b140!2sShashemene%2C%20Ethiopia!5e0!3m2!1sen!2set!4v1620000000000!5m2!1sen!2set" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen 
            loading="lazy"
            title="Shashemene Map"
          ></iframe>
        </div>
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-white dark:from-primary via-transparent to-white dark:to-primary opacity-100"></div>
        <div className="relative z-10 h-full flex items-center justify-center">
          <div className="p-12 bg-white/80 dark:bg-primary/80 backdrop-blur-xl rounded-[3rem] border border-white/20 shadow-2xl text-center max-w-md mx-4">
            <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center mx-auto mb-6">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-text-dark dark:text-white mb-4">Visit City Hall</h3>
            <p className="text-text-dark/60 dark:text-stone-400 font-light mb-8">
              Our administrative headquarters are located in the heart of Shashemene. We welcome visitors during official working hours.
            </p>
            <a 
              href="https://maps.google.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-accent font-bold hover:gap-3 transition-all"
            >
              Get Directions
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* Community Gallery */}
      {contactPhotos.length > 0 && (
        <section className="section-padding bg-white dark:bg-primary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-20">
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Our Community</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white leading-tight">
                Shashemene in <span className="text-accent italic font-serif">Focus</span>
              </h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {contactPhotos.map((photo, idx) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="aspect-square rounded-[2.5rem] overflow-hidden shadow-xl group relative"
                >
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-8 translate-y-4 group-hover:translate-y-0">
                    <p className="text-white text-xl font-bold mb-2">{photo.title || "Community Life"}</p>
                    <p className="text-stone-300 text-xs uppercase tracking-widest font-bold">Shashemene City</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
