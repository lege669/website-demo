import { useState, useEffect } from "react";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building2, Hotel, GraduationCap, Bus, Heart, 
  Palmtree, Factory, Globe, Landmark, MapPin, 
  Search, Filter, Loader2, ExternalLink, Phone, Camera
} from "lucide-react";

interface CityResource {
  id: string;
  name: string;
  category: string;
  description: string;
  image?: string;
  location?: string;
  website?: string;
  contact?: string;
}

const categories = [
  { id: "Infrastructure", icon: Building2, label: "Infrastructure" },
  { id: "Projects", icon: Landmark, label: "Projects" },
  { id: "Hotels", icon: Hotel, label: "Hotels" },
  { id: "Education", icon: GraduationCap, label: "Education" },
  { id: "Transportation", icon: Bus, label: "Transport" },
  { id: "CommunityServices", icon: Heart, label: "Community" },
  { id: "Culture", icon: Palmtree, label: "Culture" },
  { id: "Industry", icon: Factory, label: "Industry" },
  { id: "NGO", icon: Globe, label: "NGOs" },
  { id: "GovernmentService", icon: Landmark, label: "Gov Services" },
];

export default function Explore() {
  const [resources, setResources] = useState<CityResource[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("Infrastructure");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchResources = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, "cityResources"),
          where("category", "==", activeCategory)
        );
        const snapshot = await getDocs(q);
        const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CityResource));
        setResources(items);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, "cityResources");
      } finally {
        setLoading(false);
      }
    };

    fetchResources();
  }, [activeCategory]);

  const filteredResources = resources.filter(res => 
    res.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    res.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pt-24 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="mb-12">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-text-dark mb-4">Explore Shashemene</h1>
          <p className="text-lg text-text-dark/70 max-w-2xl">
            Discover the infrastructure, services, and landmarks that make our city a thriving hub of the Oromia region.
          </p>
        </header>

        {/* Search and Filter */}
        <div className="flex flex-col lg:flex-row gap-8 mb-12">
          <div className="lg:w-64 shrink-0">
            <div className="bg-white rounded-2xl border border-secondary p-4 sticky top-24">
              <h2 className="text-xs font-bold text-text-dark/40 uppercase tracking-widest mb-4 px-2">Categories</h2>
              <div className="space-y-1">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      activeCategory === cat.id
                        ? "bg-accent/10 text-accent"
                        : "text-text-dark/60 hover:bg-secondary/50"
                    }`}
                  >
                    <cat.icon className="w-4 h-4" />
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="relative mb-8">
              <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-text-dark/40" />
              <input
                type="text"
                placeholder={`Search in ${activeCategory}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white border border-secondary rounded-2xl shadow-sm outline-none focus:ring-2 focus:ring-accent/20 transition-all"
              />
            </div>

            {loading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <AnimatePresence mode="popLayout">
                  {filteredResources.length > 0 ? (
                    filteredResources.map((res) => (
                      <motion.div
                        key={res.id}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white rounded-2xl border border-secondary overflow-hidden hover:shadow-md transition-shadow group"
                      >
                        <div className="aspect-[16/9] overflow-hidden relative">
                          <img
                            src={res.image || `https://picsum.photos/seed/${res.id}/800/450`}
                            alt={res.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            referrerPolicy="no-referrer"
                          />
                          {!res.image && (
                            <div className="absolute inset-0 bg-primary/10 backdrop-blur-[2px] flex items-center justify-center">
                              <Camera className="w-8 h-8 text-white/50" />
                            </div>
                          )}
                        </div>
                        <div className="p-6">
                          <h3 className="text-xl font-bold text-text-dark mb-2">{res.name}</h3>
                          <p className="text-text-dark/70 text-sm leading-relaxed mb-4">{res.description}</p>
                          
                          <div className="space-y-2 border-t border-secondary/50 pt-4">
                            {res.location && (
                              <div className="flex items-center gap-2 text-sm text-text-dark/60">
                                <MapPin className="w-4 h-4 text-accent" />
                                {res.location}
                              </div>
                            )}
                            {res.contact && (
                              <div className="flex items-center gap-2 text-sm text-text-dark/60">
                                <Phone className="w-4 h-4 text-accent" />
                                {res.contact}
                              </div>
                            )}
                            {res.website && (
                              <a 
                                href={res.website} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="flex items-center gap-2 text-sm text-accent hover:underline"
                              >
                                <ExternalLink className="w-4 h-4" />
                                Visit Website
                              </a>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="col-span-full py-20 text-center">
                      <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                        <Filter className="w-8 h-8 text-text-dark/40" />
                      </div>
                      <h3 className="text-lg font-bold text-text-dark">No resources found</h3>
                      <p className="text-text-dark/50">Try adjusting your search or category.</p>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* Map Section */}
        <section className="mt-24">
          <div className="bg-white rounded-[3rem] border border-secondary overflow-hidden shadow-sm">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-12">
                <h2 className="text-3xl font-serif font-bold text-text-dark mb-6">City Location</h2>
                <p className="text-text-dark/70 mb-8 leading-relaxed">
                  Shashemene is strategically located in the West Arsi Zone of the Oromia Region, Ethiopia. It serves as a vital crossroads connecting the capital, Addis Ababa, with the southern regions of the country.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-secondary/30 rounded-2xl">
                    <MapPin className="w-5 h-5 text-accent" />
                    <span className="text-text-dark font-medium">West Arsi Zone, Oromia, Ethiopia</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-secondary/30 rounded-2xl">
                    <Globe className="w-5 h-5 text-accent" />
                    <span className="text-text-dark font-medium">Coordinates: 7.2° N, 38.6° E</span>
                  </div>
                </div>
              </div>
              <div className="h-[400px] lg:h-auto relative bg-secondary">
                {/* Static Map Placeholder */}
                <img 
                  src="https://picsum.photos/seed/shashemene-map/1200/800"
                  alt="City Map"
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white/90 backdrop-blur-md p-6 rounded-3xl shadow-xl border border-white/50 text-center">
                    <MapPin className="w-10 h-10 text-accent mx-auto mb-2 animate-bounce" />
                    <span className="font-bold text-text-dark">Shashemene City Center</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
