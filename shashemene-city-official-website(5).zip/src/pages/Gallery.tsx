import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Camera, MapPin, Maximize2, X } from "lucide-react";
import { collection, query, onSnapshot, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";

const defaultGalleryImages = [
  { id: "1", url: "https://picsum.photos/seed/shash1/1200/800", title: "City Center Skyline", category: "Urban" },
  { id: "2", url: "https://picsum.photos/seed/shash2/1200/800", title: "Traditional Market Day", category: "Culture" },
  { id: "3", url: "https://picsum.photos/seed/shash3/1200/800", title: "Rift Valley Sunset", category: "Nature" },
  { id: "4", url: "https://picsum.photos/seed/shash4/1200/800", title: "St. George Church", category: "Landmark" },
  { id: "5", url: "https://picsum.photos/seed/shash5/1200/800", title: "Community Park", category: "Nature" },
  { id: "6", url: "https://picsum.photos/seed/shash6/1200/800", title: "Industrial Zone", category: "Urban" },
  { id: "7", url: "https://picsum.photos/seed/shash7/1200/800", title: "Local Craftsmanship", category: "Culture" },
  { id: "8", url: "https://picsum.photos/seed/shash8/1200/800", title: "Main Street Traffic", category: "Urban" },
  { id: "9", url: "https://picsum.photos/seed/shash9/1200/800", title: "Lake Hawassa Proximity", category: "Nature" },
  { id: "10", url: "https://picsum.photos/seed/shash10/1200/800", title: "Historical Monument", category: "Landmark" },
  { id: "11", url: "https://picsum.photos/seed/shash11/1200/800", title: "Modern Architecture", category: "Urban" },
  { id: "12", url: "https://picsum.photos/seed/shash12/1200/800", title: "Festive Celebration", category: "Culture" },
];

export default function Gallery() {
  const [photos, setPhotos] = useState<any[]>([]);
  const [selectedImage, setSelectedImage] = useState<any | null>(null);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const q = query(collection(db, "photos"), orderBy("uploadedAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedPhotos = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        category: doc.data().section
      }));
      setPhotos(fetchedPhotos);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Gallery");
    });
    return () => unsubscribe();
  }, []);

  const displayPhotos = photos.length > 0 ? photos : defaultGalleryImages;
  const categories = ["All", ...Array.from(new Set(displayPhotos.map(p => p.category)))];
  const filteredImages = filter === "All" ? displayPhotos : displayPhotos.filter(img => img.category === filter);

  return (
    <div className="pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="mb-16 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 bg-accent/10 text-accent rounded-full text-xs font-bold tracking-widest uppercase mb-4"
          >
            <Camera className="w-3 h-3" />
            Visual Journey
          </motion.div>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-text-dark mb-6">
            Explore Shashemene in <span className="text-accent italic">Photos</span>
          </h1>
          <p className="text-lg text-text-dark/70 max-w-2xl mx-auto">
            A curated collection of images capturing the essence, beauty, and vibrant life of our city.
          </p>
        </header>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                filter === cat
                  ? "bg-accent text-white shadow-lg shadow-accent/20"
                  : "bg-white text-text-dark/60 hover:bg-secondary border border-secondary"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredImages.map((img, idx) => (
            <motion.div
              key={img.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group relative aspect-[4/5] rounded-[2rem] overflow-hidden cursor-pointer bg-secondary shadow-sm hover:shadow-xl transition-all"
              onClick={() => setSelectedImage(img)}
            >
              <img
                src={img.url}
                alt={img.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
                <div className="flex items-center gap-2 text-accent text-[10px] font-bold uppercase tracking-widest mb-2">
                  <MapPin className="w-3 h-3" />
                  Shashemene, Ethiopia
                </div>
                <h3 className="text-white font-bold text-lg leading-tight">{img.title || "Untitled"}</h3>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-white/60 text-xs">{img.category}</span>
                  <Maximize2 className="w-4 h-4 text-white/60" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Lightbox */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-12"
              onClick={() => setSelectedImage(null)}
            >
              <button
                className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors"
                onClick={() => setSelectedImage(null)}
              >
                <X className="w-8 h-8" />
              </button>
              
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative max-w-5xl w-full"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={selectedImage.url}
                  alt={selectedImage.title}
                  className="w-full h-auto max-h-[80vh] object-contain rounded-3xl shadow-2xl"
                  referrerPolicy="no-referrer"
                />
                <div className="mt-6 text-center">
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedImage.title || "Untitled"}</h2>
                  <p className="text-accent font-medium">{selectedImage.category}</p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
