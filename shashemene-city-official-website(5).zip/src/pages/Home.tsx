import { useState, useEffect } from "react";
import { motion, AnimatePresence, useScroll, useTransform } from "motion/react";
import { 
  ArrowRight, Users, Building2, TreePine, History, 
  ChevronLeft, ChevronRight, Camera, UserCheck, 
  Droplets, Landmark, DollarSign, Map as MapIcon, ShieldCheck, Star,
  Globe, Zap, Award, BarChart3
} from "lucide-react";
import { Link } from "react-router-dom";
import { collection, query, where, onSnapshot, orderBy, limit } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import NewsSection from "../components/NewsSection";

const defaultHeroImages = [
  "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&q=80&w=1920",
  "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&q=80&w=1920",
  "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?auto=format&fit=crop&q=80&w=1920",
];

const defaultGalleryImages = [
  { url: "https://picsum.photos/seed/city1/800/600", title: "City Center" },
  { url: "https://picsum.photos/seed/city2/800/600", title: "Cultural Market" },
  { url: "https://picsum.photos/seed/city3/800/600", title: "Rift Valley View" },
  { url: "https://picsum.photos/seed/city4/800/600", title: "Local Landmark" },
  { url: "https://picsum.photos/seed/city5/800/600", title: "Community Park" },
  { url: "https://picsum.photos/seed/city6/800/600", title: "Industrial Zone" },
];

const leaders = [
  { name: "Ato Bekele Tadesse", role: "City Administrator", period: "2022 - Present", icon: UserCheck, image: "https://picsum.photos/seed/admin1/400/400" },
  { name: "W/ro Chaltu Gemechu", role: "Water Bureau Admin", period: "2021 - Present", icon: Droplets, image: "https://picsum.photos/seed/admin2/400/400" },
  { name: "Ato Lemma Megersa", role: "Revenue Leader", period: "2023 - Present", icon: Landmark, image: "https://picsum.photos/seed/admin3/400/400" },
];

const stats = [
  { label: "Population", value: "250K+", icon: Users },
  { label: "Annual Growth", value: "4.2%", icon: BarChart3 },
  { label: "Global Partners", value: "15+", icon: Globe },
  { label: "City Awards", value: "8", icon: Award },
];

export default function Home() {
  const [currentImage, setCurrentImage] = useState(0);
  const [heroImages, setHeroImages] = useState<string[]>(defaultHeroImages);
  const [galleryImages, setGalleryImages] = useState<{url: string, title: string}[]>(defaultGalleryImages);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  
  const { scrollYProgress } = useScroll();
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -200]);

  useEffect(() => {
    // Fetch Hero Photos
    const heroQuery = query(
      collection(db, "photos"),
      where("section", "==", "Hero"),
      orderBy("order", "asc")
    );

    const unsubscribeHero = onSnapshot(heroQuery, (snapshot) => {
      const urls = snapshot.docs.map(doc => doc.data().url);
      if (urls.length > 0) {
        setHeroImages(urls);
      } else {
        setHeroImages(defaultHeroImages);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Hero");
    });

    // Fetch Portfolio (Gallery) Photos
    const galleryQuery = query(
      collection(db, "photos"),
      where("section", "==", "Portfolio"),
      orderBy("order", "asc")
    );

    const unsubscribeGallery = onSnapshot(galleryQuery, (snapshot) => {
      const images = snapshot.docs.map(doc => ({
        url: doc.data().url,
        title: doc.data().title || "Shashemene"
      }));
      if (images.length > 0) {
        setGalleryImages(images);
      } else {
        setGalleryImages(defaultGalleryImages);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Portfolio");
    });

    // Fetch Testimonials
    const testimonialsQuery = query(collection(db, "testimonials"), limit(6));
    const unsubscribeTestimonials = onSnapshot(testimonialsQuery, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setTestimonials(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "testimonials");
    });

    return () => {
      unsubscribeHero();
      unsubscribeGallery();
      unsubscribeTestimonials();
    };
  }, []);

  useEffect(() => {
    if (heroImages.length === 0) return;
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % heroImages.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [heroImages]);

  const nextSlide = () => setCurrentImage((prev) => (prev + 1) % heroImages.length);
  const prevSlide = () => setCurrentImage((prev) => (prev - 1 + heroImages.length) % heroImages.length);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden bg-white">
        <div className="absolute inset-0 z-0">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentImage}
              src={heroImages[currentImage]}
              initial={{ opacity: 0, scale: 1.2 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 2, ease: [0.4, 0, 0.2, 1] }}
              alt={`Shashemene Slide ${currentImage + 1}`}
              className="w-full h-full object-cover opacity-20"
              referrerPolicy="no-referrer"
            />
          </AnimatePresence>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-text-dark w-full">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="max-w-4xl"
          >
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="flex items-center gap-4 mb-8"
            >
              <span className="w-12 h-[1px] bg-accent"></span>
              <span className="text-accent font-display font-bold tracking-[0.3em] uppercase text-xs">
                The Gateway to the South
              </span>
            </motion.div>
            
            <h1 className="text-7xl md:text-[10rem] font-display font-bold leading-[0.9] mb-12 tracking-tighter">
              SHASHE<br />
              <span className="text-accent italic font-serif">MENE</span>
            </h1>
            
            <div className="flex flex-col md:flex-row items-start md:items-center gap-12">
              <p className="text-xl text-stone-600 leading-relaxed max-w-md font-light">
                A vibrant intersection of global heritage and modern commerce. Experience the pulse of Oromia's most dynamic city.
              </p>
              
              <div className="flex gap-6">
                <Link
                  to="/explore"
                  className="group relative px-12 py-5 bg-accent text-white rounded-full font-bold overflow-hidden transition-all"
                >
                  <span className="relative z-10 flex items-center gap-3">
                    Explore City
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <motion.div 
                    className="absolute inset-0 bg-accent"
                    initial={{ x: "-100%" }}
                    whileHover={{ x: 0 }}
                    transition={{ duration: 0.4 }}
                  />
                </Link>
                
                <Link
                  to="/news"
                  className="px-12 py-5 border border-stone-200 hover:bg-stone-50 rounded-full font-bold transition-all text-text-dark"
                >
                  Latest News
                </Link>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Slider Controls */}
        <div className="absolute bottom-12 right-4 sm:right-12 z-20 flex items-center gap-6">
          <div className="flex items-center gap-4 text-text-dark/50 font-display text-sm">
            <span className="text-text-dark font-bold">0{currentImage + 1}</span>
            <div className="w-20 h-[1px] bg-stone-200 relative">
              <motion.div 
                className="absolute inset-0 bg-accent"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                key={currentImage}
                transition={{ duration: 8, ease: "linear" }}
                style={{ originX: 0 }}
              />
            </div>
            <span>0{heroImages.length}</span>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={prevSlide}
              className="w-14 h-14 rounded-full border border-stone-200 flex items-center justify-center text-text-dark hover:bg-accent-hover hover:border-accent-hover hover:text-white transition-all backdrop-blur-md group"
            >
              <ChevronLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
            </button>
            <button 
              onClick={nextSlide}
              className="w-14 h-14 rounded-full border border-stone-200 flex items-center justify-center text-text-dark hover:bg-accent-hover hover:border-accent-hover hover:text-white transition-all backdrop-blur-md group"
            >
              <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white dark:bg-primary/50 border-y border-stone-200 dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-12">
            {stats.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center md:text-left"
              >
                <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                  <stat.icon className="w-6 h-6 text-accent" />
                  <span className="text-stone-400 font-display text-xs uppercase tracking-widest font-bold">{stat.label}</span>
                </div>
                <div className="text-4xl md:text-6xl font-display font-bold text-text-dark dark:text-white">{stat.value}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section-padding relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Our Legacy</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white mb-10 leading-[1.1]">
                A City Built on <span className="text-accent italic font-serif">Vision</span> and Diversity
              </h2>
              <p className="text-xl text-text-dark dark:text-stone-400 mb-12 leading-relaxed font-light">
                Shashemene is more than just a geographic location; it's a testament to Ethiopia's welcoming spirit. From its roots as a gift to the global African diaspora to its current status as a vital commercial artery, we continue to grow with purpose.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
                <div className="p-8 bg-white dark:bg-primary rounded-3xl border border-stone-100 dark:border-white/5">
                  <Zap className="w-8 h-8 text-accent" />
                  <h4 className="text-xl font-bold mb-3 dark:text-white">Rapid Innovation</h4>
                  <p className="text-stone-500 text-sm leading-relaxed">Implementing smart city solutions for a better urban experience.</p>
                </div>
                <div className="p-8 bg-white dark:bg-primary rounded-3xl border border-stone-100 dark:border-white/5">
                  <Globe className="w-8 h-8 text-accent" />
                  <h4 className="text-xl font-bold mb-3 dark:text-white">Global Connectivity</h4>
                  <p className="text-stone-500 text-sm leading-relaxed">A multicultural hub connecting Ethiopia to the world.</p>
                </div>
              </div>
              
              <Link to="/about" className="inline-flex items-center gap-3 text-text-dark dark:text-white font-bold group">
                Learn our full story
                <div className="w-12 h-12 rounded-full border border-stone-200 dark:border-white/10 flex items-center justify-center group-hover:bg-accent-hover group-hover:border-accent-hover group-hover:text-white transition-all">
                  <ArrowRight className="w-5 h-5" />
                </div>
              </Link>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="relative"
            >
              <div className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1514924013411-cbf25faa35bb?auto=format&fit=crop&q=80&w=1000" 
                  className="w-full h-full object-cover"
                  alt="City Life"
                />
              </div>
              <motion.div 
                style={{ y: y1 }}
                className="absolute -bottom-12 -left-12 w-64 h-64 bg-accent rounded-[2rem] p-10 text-white shadow-2xl hidden md:block"
              >
                <div className="text-5xl font-display font-bold mb-4">50+</div>
                <p className="text-sm font-medium opacity-80 leading-relaxed">Years of international cultural exchange and growth.</p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section-padding bg-white dark:bg-primary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
            <div className="max-w-2xl">
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Our Services</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white leading-[1.1]">
                Empowering Our <span className="text-accent italic font-serif">Citizens</span>
              </h2>
            </div>
            <p className="text-stone-500 max-w-sm font-light leading-relaxed">
              We provide essential digital and physical infrastructure to support the thriving community of Shashemene.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Public Services", icon: Landmark, desc: "Access city permits, licenses, and administrative services online with ease." },
              { title: "Business Support", icon: BarChart3, desc: "Resources and incentives for local entrepreneurs and international investors." },
              { title: "Urban Planning", icon: MapIcon, desc: "Sustainable development projects ensuring a green and organized city growth." },
            ].map((service, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group p-12 bg-white dark:bg-primary rounded-[3rem] border border-stone-100 dark:border-white/5 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500"
              >
                <div className="w-16 h-16 bg-secondary dark:bg-primary/20 rounded-2xl flex items-center justify-center mb-10 group-hover:bg-accent-hover transition-colors duration-500">
                  <service.icon className="w-8 h-8 text-accent group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-2xl font-bold text-text-dark dark:text-white mb-6">{service.title}</h3>
                <p className="text-stone-500 dark:text-stone-400 leading-relaxed mb-10">{service.desc}</p>
                <Link to="/services" className="flex items-center gap-2 text-accent font-bold group/btn">
                  Learn More
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-24">
            <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Visual Journey</span>
            <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white mb-8">
              City <span className="text-accent italic font-serif">Gallery</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-[800px]">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="md:col-span-8 relative rounded-[3rem] overflow-hidden group"
            >
              <img src={galleryImages[0]?.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Gallery" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-12">
                <h4 className="text-white text-3xl font-bold">{galleryImages[0]?.title}</h4>
              </div>
            </motion.div>
            <div className="md:col-span-4 grid grid-rows-2 gap-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="relative rounded-[3rem] overflow-hidden group"
              >
                <img src={galleryImages[1]?.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Gallery" />
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="relative rounded-[3rem] overflow-hidden group"
              >
                <img src={galleryImages[2]?.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Gallery" />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="section-padding bg-white text-text-dark relative overflow-hidden border-y border-stone-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-24">
            <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Our Leadership</span>
            <h2 className="text-5xl md:text-7xl font-display font-bold mb-8">
              The Minds Behind <span className="text-accent italic font-serif">Progress</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {leaders.map((leader, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group"
              >
                <div className="relative aspect-[4/5] rounded-[3rem] overflow-hidden mb-8 shadow-xl">
                  <img src={leader.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale group-hover:grayscale-0" alt={leader.name} />
                  <div className="absolute inset-0 bg-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
                <h3 className="text-2xl font-bold mb-2 text-text-dark">{leader.name}</h3>
                <p className="text-accent font-display text-sm uppercase tracking-widest font-bold">{leader.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      {testimonials.length > 0 && (
        <section className="section-padding bg-white dark:bg-primary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-24">
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Community Voice</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white mb-8">
                What Our <span className="text-accent italic font-serif">Citizens</span> Say
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((t, idx) => (
                <motion.div
                  key={t.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-12 bg-white dark:bg-primary rounded-[3rem] border border-stone-100 dark:border-white/5"
                >
                  <div className="flex gap-1 mb-8">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${i < t.rating ? "text-amber-400 fill-amber-400" : "text-stone-200"}`} 
                      />
                    ))}
                  </div>
                  <p className="text-xl text-text-dark dark:text-stone-400 italic mb-10 leading-relaxed">"{t.content}"</p>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full bg-secondary dark:bg-primary/30 flex items-center justify-center text-accent font-bold text-xl">
                      {t.authorName.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-text-dark dark:text-white">{t.authorName}</h4>
                      <p className="text-xs text-stone-500 uppercase tracking-widest font-bold">{t.authorRole}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Dynamic News Section */}
      <section className="section-padding">
        <NewsSection />
      </section>
      
      {/* Newsletter Section */}
      <section className="section-padding bg-accent relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
        </div>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-5xl md:text-7xl font-display font-bold text-white mb-10 leading-tight">
            Stay Updated with <br /> <span className="italic font-serif">City Progress</span>
          </h2>
          <p className="text-secondary text-xl mb-12 max-w-2xl mx-auto font-light">
            Join our newsletter to receive the latest news, events, and development updates directly in your inbox.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
            <input 
              type="email" 
              placeholder="Enter your email address" 
              className="flex-grow px-8 py-5 rounded-full bg-white/10 border border-white/20 text-white placeholder:text-secondary/50 outline-none focus:bg-white/20 transition-all"
            />
            <button className="px-12 py-5 bg-white text-accent rounded-full font-bold hover:bg-secondary transition-all">
              Subscribe Now
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
