import { useState, useEffect } from "react";
import { collection, query, orderBy, getDocs, where, onSnapshot } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { motion } from "motion/react";
import { Calendar, Tag, ArrowRight, Loader2, Newspaper, Camera, Search, Filter } from "lucide-react";
import { Link } from "react-router-dom";

interface NewsItem {
  id: string;
  title: string;
  content: string;
  date: string;
  image?: string;
  category: string;
}

export default function News() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [blogPhotos, setBlogPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  useEffect(() => {
    const fetchNews = async () => {
      setLoading(true);
      try {
        const q = query(collection(db, "news"), orderBy("date", "desc"));
        const snapshot = await getDocs(q);
        const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as NewsItem));
        setNews(items);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, "news");
      } finally {
        setLoading(false);
      }
    };

    fetchNews();

    const qPhotos = query(
      collection(db, "photos"),
      where("section", "==", "Blog"),
      orderBy("order", "asc")
    );
    const unsubscribePhotos = onSnapshot(qPhotos, (snapshot) => {
      const fetchedPhotos = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBlogPhotos(fetchedPhotos);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Blog");
    });

    return () => unsubscribePhotos();
  }, []);

  const categories = ["All", ...Array.from(new Set(news.map(item => item.category)))];

  const filteredNews = news.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         item.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-40 pb-24 bg-white dark:bg-primary/30 border-b border-secondary dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">City Updates</span>
              <h1 className="text-6xl md:text-8xl font-display font-bold text-text-dark dark:text-white mb-8 leading-[1.1]">
                News & <span className="text-accent italic font-serif">Stories</span>
              </h1>
              <p className="text-xl text-text-dark/70 dark:text-text-dark/40 leading-relaxed font-light mb-12">
                Stay informed about the latest announcements, community projects, and upcoming events in Shashemene.
              </p>
              
              <div className="flex flex-col md:flex-row gap-6">
                <div className="relative flex-1 group">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-text-dark/40 group-focus-within:text-accent transition-colors" />
                  <input 
                    type="text"
                    placeholder="Search articles..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-16 pr-8 py-5 bg-white dark:bg-primary border border-secondary dark:border-white/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all text-text-dark dark:text-white"
                  />
                </div>
                <div className="relative group">
                  <Filter className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-text-dark/40 group-focus-within:text-accent transition-colors" />
                  <select 
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="pl-16 pr-12 py-5 bg-white dark:bg-primary border border-secondary dark:border-white/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all text-text-dark dark:text-white appearance-none cursor-pointer min-w-[200px]"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* News Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center py-40">
              <Loader2 className="w-12 h-12 text-accent animate-spin" />
            </div>
          ) : filteredNews.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {filteredNews.map((item, idx) => (
                <motion.article
                  key={item.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="group bg-white dark:bg-primary rounded-[3rem] border border-secondary/50 dark:border-white/5 overflow-hidden hover:shadow-2xl hover:shadow-accent/5 transition-all duration-500"
                >
                  <div className="aspect-[16/10] overflow-hidden relative">
                    <img 
                      src={item.image || `https://picsum.photos/seed/${item.id}/800/500`} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-6 left-6">
                      <span className="px-4 py-2 bg-white/90 dark:bg-primary/90 backdrop-blur-md text-accent dark:text-accent text-[10px] font-bold uppercase tracking-widest rounded-full shadow-lg">
                        {item.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-10">
                    <div className="flex items-center gap-6 text-text-dark/40 text-[10px] font-bold uppercase tracking-widest mb-6">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-accent" />
                        {new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-accent" />
                        {item.category}
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-text-dark dark:text-white mb-6 group-hover:text-accent transition-colors line-clamp-2 leading-tight">
                      {item.title}
                    </h3>
                    <p className="text-text-dark/60 dark:text-text-dark/40 text-sm leading-relaxed mb-10 line-clamp-3 font-light">
                      {item.content}
                    </p>
                    <button className="flex items-center gap-3 text-accent font-bold text-sm group/btn">
                      Read Full Story
                      <div className="w-10 h-10 rounded-full border border-accent/20 flex items-center justify-center group-hover/btn:bg-accent group-hover/btn:text-white transition-all">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </button>
                  </div>
                </motion.article>
              ))}
            </div>
          ) : (
            <div className="text-center py-40 bg-white dark:bg-primary/30 rounded-[4rem] border border-secondary/50 dark:border-white/5">
              <Newspaper className="w-24 h-24 text-secondary mx-auto mb-8" />
              <h3 className="text-3xl font-bold text-text-dark dark:text-white mb-4">No news found</h3>
              <p className="text-text-dark/50 dark:text-text-dark/40 font-light">Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      </section>

      {/* Blog Photos Gallery */}
      {blogPhotos.length > 0 && (
        <section className="section-padding bg-white dark:bg-primary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-20">
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Visual Stories</span>
              <h2 className="text-5xl md:text-7xl font-display font-bold text-text-dark dark:text-white leading-tight">
                Shashemene in <span className="text-accent italic font-serif">Focus</span>
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {blogPhotos.map((photo, idx) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="rounded-[3rem] overflow-hidden shadow-2xl aspect-[4/5] relative group"
                >
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-10 translate-y-4 group-hover:translate-y-0 transition-all duration-500 opacity-0 group-hover:opacity-100">
                    <h3 className="text-white font-bold text-2xl mb-4">{photo.title || "Visual Story"}</h3>
                    <p className="text-secondary/70 text-sm line-clamp-2 font-light leading-relaxed mb-6">{photo.description}</p>
                    <div className="flex items-center gap-3 text-accent text-xs font-bold uppercase tracking-widest">
                      View Details
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
