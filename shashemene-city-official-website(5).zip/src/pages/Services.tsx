import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { FileText, Zap, Droplets, ShieldCheck, Bus, GraduationCap, Camera, ArrowRight, CheckCircle2, Search } from "lucide-react";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";

export default function Services() {
  const [servicePhotos, setServicePhotos] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const q = query(
      collection(db, "photos"),
      where("section", "==", "Services"),
      orderBy("order", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const photos = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setServicePhotos(photos);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "photos/Services");
    });

    return () => unsubscribe();
  }, []);

  const services = [
    {
      icon: FileText,
      title: "Permits & Licenses",
      desc: "Apply for business licenses, building permits, and other administrative certifications with our streamlined digital portal.",
      color: "bg-blue-500/10 text-blue-500",
      features: ["Business Registration", "Construction Permits", "Event Licensing"]
    },
    {
      icon: Zap,
      title: "Energy & Utilities",
      desc: "Manage your electricity connections, report outages, and pay utility bills online through our secure payment gateway.",
      color: "bg-yellow-500/10 text-yellow-500",
      features: ["Bill Payment", "Outage Reporting", "New Connections"]
    },
    {
      icon: Droplets,
      title: "Water Services",
      desc: "Access clean water services, report leaks, and manage your water account with real-time usage tracking.",
      color: "bg-cyan-500/10 text-cyan-500",
      features: ["Usage Tracking", "Leak Reporting", "Account Management"]
    },
    {
      icon: ShieldCheck,
      title: "Public Safety",
      desc: "Emergency services, community policing, and fire department information to ensure the safety of all Shashemene residents.",
      color: "bg-red-500/10 text-red-500",
      features: ["Emergency Response", "Community Policing", "Fire Safety"]
    },
    {
      icon: Bus,
      title: "Transportation",
      desc: "Public transit routes, parking information, and road maintenance updates to keep the city moving efficiently.",
      color: "bg-orange-500/10 text-orange-500",
      features: ["Transit Routes", "Parking Permits", "Road Maintenance"]
    },
    {
      icon: GraduationCap,
      title: "Education",
      desc: "Information on local schools, vocational training, and community libraries for lifelong learning and growth.",
      color: "bg-purple-500/10 text-purple-500",
      features: ["School Directory", "Vocational Training", "Public Libraries"]
    },
  ];

  const filteredServices = services.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-40 pb-24 bg-white dark:bg-primary/30 border-b border-secondary dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Public Resources</span>
              <h1 className="text-6xl md:text-8xl font-display font-bold text-text-dark dark:text-white mb-8 leading-[1.1]">
                Empowering Our <span className="text-accent italic font-serif">Community</span>
              </h1>
              <p className="text-xl text-text-dark/70 dark:text-text-dark/40 leading-relaxed font-light mb-12">
                Access essential government services and resources designed to support our residents and businesses. We're committed to transparency and efficiency.
              </p>
              
              <div className="relative max-w-xl group">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-text-dark/40 group-focus-within:text-accent transition-colors" />
                <input 
                  type="text"
                  placeholder="Search for a service..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-16 pr-8 py-5 bg-white dark:bg-primary border border-secondary dark:border-white/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all text-text-dark dark:text-white"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredServices.map((service, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group p-10 bg-white dark:bg-primary rounded-[3rem] border border-secondary/50 dark:border-white/5 hover:border-accent/30 transition-all duration-500 shadow-sm hover:shadow-2xl hover:shadow-accent/5"
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6 ${service.color}`}>
                  <service.icon className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-text-dark dark:text-white mb-6">{service.title}</h3>
                <p className="text-text-dark/60 dark:text-text-dark/40 leading-relaxed font-light mb-8">
                  {service.desc}
                </p>
                
                <ul className="space-y-4 mb-10">
                  {service.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-center gap-3 text-sm text-text-dark/70 dark:text-text-dark/40">
                      <CheckCircle2 className="w-4 h-4 text-accent" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button className="w-full py-4 bg-secondary/50 dark:bg-primary/50 text-text-dark dark:text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 group-hover:bg-accent group-hover:text-white transition-all">
                  Access Service
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </div>

          {filteredServices.length === 0 && (
            <div className="text-center py-24">
              <p className="text-text-dark/50 text-lg">No services found matching your search.</p>
            </div>
          )}
        </div>
      </section>

      {/* Service Highlights Gallery */}
      {servicePhotos.length > 0 && (
        <section className="section-padding bg-white dark:bg-primary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-16">
              <div className="max-w-2xl">
                <span className="text-accent font-display font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Visual Highlights</span>
                <h2 className="text-5xl md:text-6xl font-display font-bold text-text-dark dark:text-white leading-tight">
                  Services in <span className="text-accent italic font-serif">Action</span>
                </h2>
              </div>
              <div className="flex gap-4">
                <button className="w-14 h-14 rounded-full border border-secondary dark:border-white/10 flex items-center justify-center hover:bg-white dark:hover:bg-primary/50 transition-all">
                  <ArrowRight className="w-6 h-6 rotate-180" />
                </button>
                <button className="w-14 h-14 rounded-full bg-accent text-white flex items-center justify-center hover:bg-accent-hover transition-all">
                  <ArrowRight className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {servicePhotos.map((photo, idx) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="relative aspect-[4/5] rounded-[2.5rem] overflow-hidden group shadow-xl"
                >
                  <img 
                    src={photo.url} 
                    alt={photo.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-8 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-4 group-hover:translate-y-0">
                    <p className="text-white text-xl font-bold mb-2">{photo.title || "Service Excellence"}</p>
                    <p className="text-secondary/70 text-xs uppercase tracking-widest font-bold">Shashemene City</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Support Banner */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-accent rounded-[4rem] p-12 md:p-24 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 translate-x-1/4"></div>
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-5xl md:text-7xl font-display font-bold mb-8 leading-tight">
                  Need <span className="italic font-serif">Personalized</span> Assistance?
                </h2>
                <p className="text-secondary text-xl font-light leading-relaxed mb-12">
                  Our support team is available Monday to Friday, 8:30 AM to 5:30 PM, to help you with any city-related inquiries. We're here to serve you.
                </p>
                <div className="flex flex-wrap gap-6">
                  <button className="px-10 py-5 bg-white text-accent rounded-full font-bold hover:bg-secondary transition-all flex items-center gap-3">
                    Contact Help Desk
                    <ArrowRight className="w-5 h-5" />
                  </button>
                  <div className="flex items-center gap-4 px-8 py-5 border border-white/20 rounded-full">
                    <div className="w-3 h-3 bg-accent/50 rounded-full animate-pulse"></div>
                    <span className="text-sm font-bold uppercase tracking-widest">Support Online</span>
                  </div>
                </div>
              </div>
              <div className="hidden lg:block">
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { label: "Response Time", val: "< 24h" },
                    { label: "Satisfaction", val: "98%" },
                    { label: "Daily Users", val: "5k+" },
                    { label: "Services", val: "50+" },
                  ].map((stat, idx) => (
                    <div key={idx} className="p-8 bg-white/10 backdrop-blur-md rounded-3xl border border-white/10">
                      <div className="text-3xl font-display font-bold mb-2">{stat.val}</div>
                      <div className="text-xs uppercase tracking-widest font-bold opacity-60">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
